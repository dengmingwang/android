package com.example.singlepoct.utils;

import android.content.Context;
/**
 * @Author
 * @Time 2022/8/4 9:05
 * @Description
 */
public class ScreenUtils {
    /**
     * 获取屏幕高度(px)
     */ public static int getScreenHeight(Context context) {
        return context.getResources().getDisplayMetrics().heightPixels;
    }
    /**
     * 获取屏幕宽度(px)
     */ public static int getScreenWidth(Context context) {
        return context.getResources().getDisplayMetrics().widthPixels;
    }
}