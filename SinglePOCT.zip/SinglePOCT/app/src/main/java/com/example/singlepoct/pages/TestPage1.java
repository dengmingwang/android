package com.example.singlepoct.pages;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.example.singlepoct.Bean.OrdinaryData;
import com.example.singlepoct.Bean.UploadBean;
import com.example.singlepoct.R;
import com.example.singlepoct.utils.PrintfUtil;
import com.example.singlepoct.utils.ScreenUtils;
import android_serialport_api.SerialHelper;
import com.example.singlepoct.utils.Tools;

import org.litepal.LitePal;
import org.litepal.crud.DataSupport;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import android_serialport_api.ComBean;

public class TestPage1 extends AppCompatActivity implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {

    private Handler mHandler=new Handler(){
        @Override
        public void handleMessage(Message msg){
            switch(msg.what) {
                case 0:
                    text_Date.setText(Str_Date);
                    text_time.setText(Str_Time);
                    break;
                case 1:
                    //  private TextView text_SampleNum,text_Index2,text_Project,text_SampleType;
                    //获取样本号、流水号和样本类型；
                    text_SampleNum.setText(edit_sampleNum.getText().toString());
                    text_Index2.setText(text_index.getText().toString());
                    text_SampleType.setText(sprinner_SampleType.getSelectedItem().toString());
                    break;
                case 2:
                    SetSerialNumber();   // 更新流水号。
                    edit_sampleNum.setText("");   //清理样本号选框。
                    break;
                case 3: //获得项目名：
//                    Text_receive.setText(Receive1);
                    text_Project.setText(Receive1);
                    //  private TextView text_SampleNum,text_Index2,text_Project,text_SampleType;
                    //获取样本号、流水号和样本类型；
                    text_SampleNum.setText(edit_sampleNum.getText().toString());
                    text_Index2.setText(text_index.getText().toString());
                    text_SampleType.setText(sprinner_SampleType.getSelectedItem().toString());
                    break;
                case 4://获得子项目名：
//                    Text_receive.setText(Receive1);
                    text_Subproject.setText(Receive1);
                    break;
                case 5: //显示结果值的同时，显示项目信息
                    text_ConcentrationVvalue.setText(Receive1);
                    text_unit.setText("mol/L");
//                    //恢复操作按钮：
//                    RecoverView();
                    break;
                case 6: //显示测试卡读数错误弹窗。
                    ReadID_DialogFlag=true;
                    readDialog();
                    break;
                case 7:
                    RecoverView();
                    break;
                default:
                    break;
            }
        }

    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_page1);
        Log.d("当前时间2",Tools.getDate().get(1));
        initUart(); //通讯串口
        initUart3(); //打印串口
        BindComponent();
        SetSerialNumber();   // 暂时先屏蔽一下流水号设置。
        Task1 task1= new Task1();
        mHandler.postDelayed(task1,0);
        LitePal.getDatabase();
        startLocatin();//初始化定位相关函数
    }



    private String locateStr;
    public LocationClient mLocationClient;
    private void startLocatin() {
        //没有它，会报错：Please recheck the setAgreePrivacy interface
        mLocationClient.setAgreePrivacy(true);
        try {
            //首先创建了一个LocationClient的实例，LocationClient的构建函数接收一个Context参数，
            //这里调用getApplicationContext()方法来获取一个全局的Context参数并传入。
            mLocationClient = new LocationClient(getApplicationContext());
        } catch (Exception e) {
            e.printStackTrace();
        }
        //然后调用LocationClient的registerLocationListener()方法来注册一个定位监听器，当获取到位置信息的时候，就会回调这个定位监听器。
        mLocationClient.registerLocationListener(new MyLocationListener());

//        positionText = (TextView) findViewById(R.id.position_text_view);
        //怎样才能在运行时一次性申请3个权限呢?
        //创建一个空的List集合，然后依次判断这3个权限有没有被授权，
        //如果没被授权就添加到List集合中，最后将List转换成数组，
        //再调用ActivityCompat.requestPermissions()方法一次性申请。
        List<String> permissionList = new ArrayList<>();
        if (ContextCompat.checkSelfPermission(TestPage1.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissionList.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (ContextCompat.checkSelfPermission(TestPage1.this,Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            permissionList.add(Manifest.permission.READ_PHONE_STATE);
        }
        if (ContextCompat.checkSelfPermission(TestPage1.this,Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            permissionList.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (! permissionList.isEmpty()) {
            String [] permissions = permissionList.toArray(new String[permissionList.size()]);
            ActivityCompat.requestPermissions(TestPage1.this,permissions,1);
        } else {
            requestLocation();
        }
        initLocation();
    }

    private void requestLocation() {
        mLocationClient.start();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1:
                if (grantResults.length > 0) {
                    for (int result : grantResults) {
                        if (result != PackageManager.PERMISSION_GRANTED) {
                            Toast.makeText(this,"必须同意所有权限才能使用本程序",Toast.LENGTH_SHORT).show();
                            finish();
                            return;
                        }
                    }
                    requestLocation();
                } else {
                    Toast.makeText(this,"发生未知错误",Toast.LENGTH_SHORT).show();
                    finish();
                }
                break;
            default:
        }
    }

    private void initLocation(){
        LocationClientOption option = new LocationClientOption();
        option.setScanSpan(5000); option.setIsNeedAddress(true);
        mLocationClient.setLocOption(option);
    }
    public class MyLocationListener implements BDLocationListener {
        /**
         * MyLocationListener的onReceiveLocation()方法中:
         * 通过BDLocation的getLatitude()方法获取当前位置的纬度,
         * 通过getLongitude()方法获取当前位置的经度，
         * 通过getLocType()方法获取当前的定位方式，最终将结果组装成一个字符串，显示到TextView上面。
         */
        @Override
        public void onReceiveLocation(BDLocation location) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    StringBuilder currentPosition = new StringBuilder();
//                    currentPosition.append("纬度：").append(location.getLatitude()). append("\n");
//                    currentPosition.append("经线：").append(location.getLongitude()). append("\n");
//                    currentPosition.append("国家：").append(location.getCountry()). append("\n");
//                    currentPosition.append("省：").append(location.getProvince()). append("\n");
//                    currentPosition.append("市：").append(location.getCity()). append("\n");
//                    currentPosition.append("区：").append(location.getDistrict()). append("\n");
//                    currentPosition.append("街道：").append(location.getStreet()). append("\n");
//                    currentPosition.append(location.getCountry()). append("\n");
                    currentPosition.append(location.getProvince()). append("-");
                    currentPosition.append(location.getCity()). append("-");
                    currentPosition.append(location.getDistrict()). append("-");
                    currentPosition.append(location.getStreet()). append("\n");
                    currentPosition.append("定位方式：");
                    if (location.getLocType() == BDLocation.TypeGpsLocation) { currentPosition.append("GPS"); }
                    else if (location.getLocType() == BDLocation.TypeNetWorkLocation)
                    { currentPosition.append("网络"); }
                    locateStr= String.valueOf(currentPosition);
                    Log.d("当前位置",locateStr);
                }
            });
        }
    }


    /**
     * @Author hang
     * @Time 2022/9/19 13:40
     * @Description 进入界面时，设置流水号。
     */
    private void SetSerialNumber() {
        //1.从保存的数据库中，获取最近的一次的实验数据的流水号：
        OrdinaryData ordinaryData = DataSupport.findLast(OrdinaryData.class);
        String LastSerialNum;
        if(ordinaryData==null){  //排除一下，程序第一次启动时，没有历史记录的情况。
            LastSerialNum="";
        }else{
            LastSerialNum= ordinaryData.getIndex();
            Log.d("LastSerialNum",LastSerialNum);
        }
        String setStr= Tools.CreateSerialNumber(LastSerialNum);
        text_index.setText(setStr);
    }

//    private String CurName;
//    private String CurAge;
//    private String CurAgeUnit;
//    private String CurAgender;


    private Button btnTestMode;
    private TextView text_Date,text_time;
    private Button btn_totalBack,btn_test,btn_ReadID,btn_print,btn_advancedInfo,btn_increase,btn_decrease;
    private EditText edit_sampleNum;
    private TextView text_userCode,text_index;
    private Spinner sprinner_SampleType;
    private Switch switch_Scan,switch_Mode;




    private String[] starArray1 = { "全血", "血清" ,"血浆","血清/血浆","末梢血","质控","其它"};//用来表示孔位字符串数组     孔位的数字中间是不留空格。

    /**页面下方输出的测试结果文本信息*/
    private TextView text_SampleNum,text_Index2,text_Project,text_SampleType;  //其中，样本号、流水号和样本类型是由上方输入信息确定，
    // 测试项目应该是读ID卡的信息获得。
    /** 子项目名、测试浓度、单位*/
    private TextView  text_Subproject,text_ConcentrationVvalue,text_unit;
    private void BindComponent() {
        //菜单按钮
        btn_totalBack=findViewById(R.id.Menu_Back);
        btn_totalBack.setOnClickListener(this);

        btn_test=findViewById(R.id.Btn_test);
        btn_test.setOnClickListener(this);
        btn_ReadID=findViewById(R.id.Btn_ReadID);
        btn_ReadID.setOnClickListener(this);
        btn_print=findViewById(R.id.Btn_printf);
        btn_print.setOnClickListener(this);

        //条码模式：
        btnTestMode=findViewById(R.id.Btn_TestMode);
        btnTestMode.setOnClickListener(this);

        btn_advancedInfo=findViewById(R.id.Advanced_Info);
        btn_advancedInfo.setOnClickListener(this);
        //
        btn_increase=findViewById(R.id.Btn_Increase);
        btn_increase.setOnClickListener(this);
        btn_decrease=findViewById(R.id.Btn_Decrease);
        btn_decrease.setOnClickListener(this);

        //时间Text
        text_Date=findViewById(R.id.Text_Date);
        text_time=findViewById(R.id.Text_Time);
        text_userCode =findViewById(R.id.Text_UserID);

        //Switch 开关：
        switch_Scan=findViewById(R.id.Switch_Scanner);
        switch_Scan.setOnCheckedChangeListener(this);
        switch_Mode=findViewById(R.id.Switch_Mode);
        switch_Mode.setOnCheckedChangeListener(this);
        //下拉表格：
        sprinner_SampleType=findViewById(R.id.spinner_SampleType);
        Tools.initSpinner(this,sprinner_SampleType,starArray1);

        //页面上方设置区域显示的流水号：
        text_index=findViewById(R.id.Text_Index);
        edit_sampleNum =findViewById(R.id.Edit_SampleNum);
        edit_sampleNum.setOnClickListener(this);
        //页面下方区域，显示相关结果信息的数据。
        text_SampleNum=findViewById(R.id.Text_SampleNum);
        text_Index2=findViewById(R.id.Text_Index2);
        text_Project=findViewById(R.id.Text_Project);
        text_SampleType=findViewById(R.id.Text_SampleType);
        text_Subproject=findViewById(R.id.Text_Subproject);
        text_ConcentrationVvalue=findViewById(R.id.Text_ConcentrationValue);
        text_unit=findViewById(R.id.Text_Unit);
    }
    HashMap hm=new HashMap();
    /*转换后指令*/
    ArrayList<String> sendHexList= new ArrayList<>();
    private void initSendTemplate(){
        //指令格式: EE [1] [2] [3] [4] [5] [6] FF
        String str1="EE01FF";//运行到条码扫描位：
        String str2="EE02FF";//运行到检测窗起点：
        String str3="EE03FF";//向后初始化;
        String str4="EE04FF";//向前初始化;
        String str5="EE05FF";//仪器初始化;;
        String str6="EE06FF";//读取当前电压值;
        String str7="EE07FF";//读取条码,并显示在屏幕上;
        String str11="EE11FF";//PC 检测; //发送检测数据给PC机
        String str12="EE12FF";//即时 检测;
        String str13="EE13FF";//定时 检测 ;
        String str14="EE14FF";//测试曲线;
        String str15="EE15FF";////开灯;
        String str16="EE16FF";////关灯;
        sendHexList.add("");
        sendHexList.add(str1);
        sendHexList.add(str2);
        sendHexList.add(str3);
        sendHexList.add(str4);
        sendHexList.add(str5);
        sendHexList.add(str6);
        sendHexList.add(str7);
        sendHexList.add(str11);
        sendHexList.add(str12);
        sendHexList.add(str13);
        sendHexList.add(str14);
        sendHexList.add(str15);
        sendHexList.add(str16);
    }
    //每个指令执行完成后，应该是有一个弹窗反馈：提示2S后自动退出，或者用户点击后退出。
    int use_Code=1;
    private boolean Adv_dialogFlag=false;
    private Boolean TestMode=false;
    /**判断当前测试是否完成*/
    private Boolean testflag=false;
    @Override
    public void onClick(View view) {
        int id= view.getId();
        try {
            Tools.newBuzzer(true);
            Thread.sleep(100);
            Tools.newBuzzer(false);
            Thread.sleep(100);
            Tools.newBuzzer(false);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        switch (id){
            case R.id.Menu_Back:
                Intent intent = new Intent(TestPage1.this, MainActivity.class);
                startActivity(intent);
                if(serialHelper.isOpen()){
                    serialHelper.close();
                    Log.d("串口1关闭","");
                }
                if(serialHelper3.isOpen()){
                    serialHelper3.close();
                    Log.d("串口3关闭","");
                }
                finish();
                break;
            case R.id.Btn_ReadID:
                //下位机执行按键功能时，接受指令后应先判断器件是否处于正确状态,如果异常，给上位机发送Flag标志位，进行弹窗提示。
//                serialHelper.sendHex("EE01FF");
//                ReadID_DialogFlag=true;
//                readDialog();
                Message message =new Message();
                message.what=6;
                mHandler.sendMessage(message);


                break;
            case R.id.Btn_test:
                HideView();
                if(TestMode){  //当前选择标准模式：即定时模式。
                    serialHelper.sendHex("EE13FF");
                    Log.d("发送数据","EE13FF");
                }else {   //选择即时模式

                    serialHelper.sendHex("EE12FF");
                    Log.d("发送数据","EE12FF");
                }
                break;
            case R.id.Btn_printf:
                //隐藏键盘
                HideView();
                //打印前，判断当前是否测试完成项目：
                MyThread myThread =new MyThread();
                new Thread(myThread).start();
                break;
            case R.id.Btn_Increase:
                use_Code++;
                text_userCode.setText(String.valueOf(use_Code));

                break;
            case R.id.Btn_Decrease:
                if (use_Code>0){
                    use_Code--;
                }
                text_userCode.setText(String.valueOf(use_Code));

                break;
            case R.id.Advanced_Info:
                Adv_dialogFlag=true;
                AdvDialog();
                break;
            case R.id.Btn_TestMode:
                if(use_Code==0){  //两条线
                    serialHelper.sendHex("EE1700FF");
                    Log.d("发送数据","EE1700FF");
                }else if (use_Code==1) { //0  无条码
                    serialHelper.sendHex("EE1701FF");
                    Log.d("发送数据","EE1701FF");
                }
                else if (use_Code==2) { //三条线
                    serialHelper.sendHex("EE1702FF");
                    Log.d("发送数据","EE1702FF");
                }else if(use_Code==3){   //四条线
                    serialHelper.sendHex("EE1703FF");
                    Log.d("发送数据","EE1703FF");
                }
                break;
            case R.id.Edit_SampleNum:
                edit_sampleNum.setText("");
                if(edit_sampleNum.isFocused())
                break;
            default:
                break;
        }
    }


    /**
     * @Author
     * @Time 2022/7/20 10:07
     * @Description 在读卡测试器件，隐藏高级信息和右侧的三个按钮。即使其不可见，不能被点击到。
     */
    private void HideView() {
        btn_test.setVisibility(View.INVISIBLE);
        btn_ReadID.setVisibility(View.INVISIBLE);
        btn_print.setVisibility(View.INVISIBLE);
        btn_advancedInfo.setVisibility(View.INVISIBLE);
    }
    /**
     * @Author
     * @Time 2022/10/12 19:48
     * @Description
     */
    private void RecoverView() {
        btn_test.setVisibility(View.VISIBLE);
        btn_ReadID.setVisibility(View.VISIBLE);
        btn_print.setVisibility(View.VISIBLE);
        btn_advancedInfo.setVisibility(View.VISIBLE);
    }

    private  Boolean isScanFlag=false;
    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        switch (compoundButton.getId()){
            case R.id.Switch_Scanner:
                if(b){//使用扫码枪
                    isScanFlag=true;
                }else {
                    isScanFlag=false;
                }
                break;
            case R.id.Switch_Mode:
                if(b){ //标准测试
                    TestMode=true;
                }else {
                    TestMode=false;
                }
                break;
            default:
                break;
        }
    }

    /** */
    StringBuilder VoltageBuffer = new StringBuilder();
    /** 缓存标志位*/
    private  boolean isReceiveFlag=false;

    /**测试完成，并获取到完整数据*/
    private Boolean isTestOK=false;
    /**条码值*/
    private String barcodeStr="";
    /**子项目名*/
    private String ItemStr="";
    /**测试项目*/
    private String ProjectStr="";
    /**串口连接类：*/
    private SerialHelper serialHelper;
    private String Receive1;
    //串口初始化
    private void initUart() {
        String UartIdStr=getCurrentTime1();
        serialHelper = new SerialHelper() {
            @Override
            protected void onDataReceived(final ComBean ComRecData) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Log.d("UartId",UartIdStr);
                        //接收16进制数据：
                        String receiveData = new String(ComRecData.bRec);
                        Log.d("ASCII码",receiveData);
                        String BytesToStr =Tools.byteToHexStr(ComRecData.bRec);   //将 接收的16进制数转换成：16进制字符串
                        Log.d("接收到单次的Hex数据的字节数据为", String.valueOf(BytesToStr.length()/2));
                        Log.d("16进制",BytesToStr);
                        if(BytesToStr.length()<8){
                            return;
                        }
                        String StrStart=BytesToStr.substring(0,4);
                        String EndStart=BytesToStr.substring(BytesToStr.length()-4);
                        char[] data16=BytesToStr.toCharArray();
                        if(BytesToStr.equals("AA55FFFE")){//测试结束：
                            //弹出按钮
                            RecoverView();
                            if(isTestOK){
                                TestCompleteTime=TimeStr;
                                //发送数据 和保存数据
                                MySendThread sendThread = new MySendThread();
                                new Thread(sendThread).start();

//                                刷新页面下方结果数据
                                Message message =new Message();
                                message.what=1;
                                mHandler.sendMessage(message);
                                isTestOK=false;
                            }
                            return ;
                        }
                        if(StrStart.equals("AA55") && EndStart.equals("FFFE")){  //解析数据：一个字节是一个数据；汉字是2个字节白表示一个值。
                            if(data16[5]=='1'){
                                String  str =BytesToStr.substring(6,BytesToStr.length()-4);
                                Log.d("str",str);
                                int n= ((BytesToStr.length()-4)-6)/2;
                                Log.d("数值为：", String.valueOf(n));

                                String  strX=BytesToStr.substring(6,10);
                                Log.d("strX",strX);
                                int anInt = Integer.parseInt(strX, 16);

                                Log.d("当前电压值", String.valueOf(anInt));
                                Receive1= String.valueOf(anInt);
                                Log.d("Receive1",Receive1);

                            }else if(data16[5]=='2'){  //这发送的条码值应该是数值
//                                String  str =BytesToStr.substring(6,BytesToStr.length()-4);
//                                Log.d("str",str);
//                                int n= ((BytesToStr.length()-4)-6)/2;
//                                 Log.d("数值为：", String.valueOf(n));
//                                Receive1= String.valueOf(Sum);
                                barcodeStr=BytesToStr;
                                Log.d("条码值",barcodeStr);
                                Message message = mHandler.obtainMessage();
                                message.what =2;
                                mHandler.sendMessage(message);
                                Toast.makeText(TestPage1.this, barcodeStr, Toast.LENGTH_SHORT).show();
                            }else if(data16[5]=='3'){ //测试项目，这应该是中文。    这个应该是条码值扫描出的结果
                                String  str =BytesToStr.substring(6,BytesToStr.length()-4);
                                String str1=Tools.hexStr2Str(str,"GB2312");
                                Log.d("文件项目名",str1);
                                Receive1=str1;
                                Message message = mHandler.obtainMessage();
                                message.what = 3;
                                mHandler.sendMessage(message);
                            }else if(data16[5]=='4'){//子项目名，这应该是字符文本。
                                String  str =BytesToStr.substring(6,BytesToStr.length()-4);
                                String str1=Tools.hexStr2Str(str,"GB2312");
                                Log.d("子项目名称",str1);
                                Receive1=str1;
                                Message message = mHandler.obtainMessage();
                                message.what = 4;
                                mHandler.sendMessage(message);
                            }else if(data16[5]=='5'){  //接收到下位机返回的结果数据值
                                String  str =BytesToStr.substring(6,BytesToStr.length()-4);
                                String str1=Tools.hexStr2Str(str,"GB2312");
                                Receive1=str1;
                                Message message = mHandler.obtainMessage();
                                message.what = 5;
                                mHandler.sendMessage(message);
                            }else if(data16[5]=='6'){
                                Log.d("扫描条码","错误");
//                                Message message = mHandler.obtainMessage();
//                                message.what = 6;
//                                mHandler.sendMessage(message);
                                Message message =new Message();
                                message.what=6;
                                mHandler.sendMessage(message);
                            }
                        }if(data16[5]=='7'){
                            isReceiveFlag=true;
                            Log.d("开始","电压曲线值");
//                            VoltageBuffer.append(BytesToStr);
//
//                            DataStr =BytesToStr.substring(6,BytesToStr.length()-4);
//                            Log.d("ReceiveStr1",DataStr);
//                            int n= ((BytesToStr.length()-4)-6)/2;
//                            Log.d("电压值的个数为：", String.valueOf(n));
//                            if(n==380){ //检测结果完整
//                                Toast.makeText(TestPage1.this, "已检测到完整的电压曲线值", Toast.LENGTH_SHORT).show();
//                                isTestOK=true;
//                                isReceiveFlag=false;
//                            }
                        }
                        if(isReceiveFlag){
                            VoltageBuffer.append(BytesToStr);
                            if (BytesToStr.length()/2==29){
                                isReceiveFlag=false;
                                String VoltageStr= VoltageBuffer.toString();
                                DataStr =VoltageStr.substring(6,VoltageStr.length()-4);
                                Log.d("ReceiveStr1",DataStr);
                                int n= ((VoltageStr.length()-4)-6)/2;
                                Log.d("电压值的个数为：", String.valueOf(n));
                                if(n==760){ //检测结果完整
                                    Toast.makeText(TestPage1.this, "已检测到完整的电压曲线值", Toast.LENGTH_SHORT).show();
                                    isTestOK=true;
                                    isReceiveFlag=false;
                                    VoltageBuffer.delete( 0, VoltageBuffer.length());
                                }
                            }
                        }
                        Log.d("msg：串口1接受数格式为：HEX", BytesToStr);
                        Log.d("msg：串口1接受数格式为：ASCLL", new String(ComRecData.bRec));

                    }
                });
            }
        };
        serialHelper.setBaudRate(9600);
        serialHelper.setPort("/dev/ttyS1");

        Log.d("Baud",String.valueOf(serialHelper.getBaudRate()));
        Log.d("setPort",serialHelper.getPort());
        try {
            serialHelper.open();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /**高级信息打印标志位*/
    private boolean printflag;

    private String PrintName;
    private String PrintAgeUint;
    private String PrintAge;
    private String PrintGender;


//        text_Project.setText(Receive1);
//    //  private TextView text_SampleNum,text_Index2,text_Project,text_SampleType;
//    //获取样本号、流水号和样本类型；
//                    text_SampleNum.setText(edit_sampleNum.getText().toString());
//                    text_Index2.setText(text_index.getText().toString());
//                    text_SampleType.setText(sprinner_SampleType.getSelectedItem().toString());
    /**当前测试卡测试完成时间时间*/
    private String TestCompleteTime="";
    PrintfUtil printfUtil =new PrintfUtil();
    private SerialHelper serialHelper3;
    //建立子线程，在子线程中处理带延时的数据指令。
    class MyThread implements Runnable {
        @Override
        public void run() {
            //1.设置打印信息
//            printfUtil.setPrintfTime();
            printfUtil.setPrintfTime(TimeStr);//打印时间
            printfUtil.setAge(PrintAge); // 年龄
            printfUtil.setAgeUnit(PrintAgeUint);//年龄单位
            printfUtil.setGender(PrintGender); //性别
            printfUtil.setReportType(0);//类型
            printfUtil.setTestTime(TestCompleteTime);//测试时间
            printfUtil.setName(PrintName);//姓名
            printfUtil.setSampleNumber(text_SampleNum.getText().toString()); //样本号
            for(i=0;i<starArray1.length;i++){
                Log.d("StringLength",starArray1.length+"");
                if(starArray1[i].equals(text_SampleType.getText().toString())){
                    printfUtil.setSampleType(i); //样本类型
                }
            }
//            printfUtil.setSampleType(sprinner_SampleType.getSelectedItemPosition()); //样本类型
            printfUtil.setSubProjectName(text_Subproject.getText().toString());//子项目名称
            printfUtil.setResultValue(text_ConcentrationVvalue.getText().toString());//结果值
            printfUtil.setSerialNumber(text_Index2.getText().toString());//流水号
            printfUtil.setBarcodeSwitch(true);
//            print
            //2.执行打印操作
            printfUtil.setSerialHelper(serialHelper3);
            printfUtil.Printer();

            Message message =new Message();
            message.what=7;
            mHandler.sendMessage(message);

        }
    }
    /**
     * @Author
     * @Time 2022/10/12 13:16
     * @Description 串口3 初始化，用来设置打印相关的数据。
     */
    private void initUart3() {
        serialHelper3 = new SerialHelper() {
            @Override
            protected void onDataReceived(final ComBean ComRecData) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        StringBuilder sMsg = new StringBuilder();
                        String receiveData = new String(ComRecData.bRec);
//                        Log.d("ASCII码",receiveData);
//                        String BytesToStr =byte2HexStr(ComRecData.bRec);   //将 接收的16进制数转换成：16进制字符串
                    }
                });
            }
        };
        serialHelper3.setBaudRate(9600);
        serialHelper3.setPort("/dev/ttyS3");

        Log.d("Baud",String.valueOf(serialHelper3.getBaudRate()));
        Log.d("setPort", serialHelper3.getPort());
        try {
            serialHelper3.open();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    /**当前的姓名选项*/
    private String nameStr="";
    private String age="";
    private String ageUnit="";
    private String GenderStr="";


    /**
     * @Author
     * @Time 2022/7/20 10:11
     * @Description 高级信息的弹窗显示：
     */
    private void AdvDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(TestPage1.this);
        final AlertDialog dialog = builder.setCancelable(false).create();
        View dialogView = View.inflate(this, R.layout.dialog_adv_infomation, null);
        //设置对话框布局
        dialog.setView(dialogView);
        //确认和取消
        Button btn_Confirm = (Button) dialogView.findViewById(R.id.btn_Confirm);
        Button btn_Cancel = (Button) dialogView.findViewById(R.id.btn_Cancel);
        EditText Name=dialogView.findViewById(R.id.Name);
        Name.setText(nameStr);
        EditText Age=dialogView.findViewById(R.id.Age);
        Age.setText(age);
        Spinner AgeUint=dialogView.findViewById(R.id.AgeUint);
        Spinner Gender =dialogView.findViewById(R.id.Gender);
        String[] starArray2 = { "岁","周"};//用来表示孔位字符串数组     孔位的数字中间是不留空格。
        String[] starArray3 = { "男","女"};//用来表示孔位字符串数组     孔位的数字中间是不留空格。
        Tools.initSpinner(TestPage1.this,AgeUint,starArray2);
        Tools.initSpinner(TestPage1.this,Gender,starArray3);

        if(AgeUint.getSelectedItem().toString().equals("周")){
            AgeUint.setSelection(1);
        }
        if(Gender.getSelectedItem().toString().equals("女")){
            Gender.setSelection(1);
        }


        btn_Confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Name.getText().toString().equals("")|| Age.getText().toString().equals("")){
//                    Toast.makeText(TestPage1.this, "请补全高级信息参数", Toast.LENGTH_SHORT).show();
                    Toast.makeText(TestPage1.this, "请补全高级信息参数", Toast.LENGTH_SHORT).show();
                    Log.d("请不全参数",".....");
                    return;
                }
                //1.姓名：
                nameStr=Name.getText().toString();
                //2.年龄
                int a = Integer.parseInt( Age.getText().toString());
                if(a>0&&a<100){
                    age= String.valueOf(a);
                }else{
                    Toast.makeText(TestPage1.this, "年龄参数有误", Toast.LENGTH_SHORT).show();
                    return;
                }
                //3.年龄单位
                ageUnit=AgeUint.getSelectedItem().toString();
                //4.性别
                GenderStr=Gender.getSelectedItem().toString();
                dialog.dismiss();
            }
        });
        btn_Cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        if(Adv_dialogFlag){
            dialog.show();
            Adv_dialogFlag=false;
        }
        //调整dialog 的View 宽度。
        dialog.getWindow().setLayout(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);//通过此方式来设置dialog 的宽高
        Window mWindow = dialog.getWindow();
        WindowManager.LayoutParams lp = mWindow.getAttributes();
        lp.x = -200; //新位置X坐标
        lp.y = -150; //新位置Y坐标
        dialog.onWindowAttributesChanged(lp);
    }

    private int n=0;
    /**
     * @Author
     * @Time 2022/7/20 10:12
     * @Description 读卡时，出现故障提示：
     */
    Context contex;
    private boolean ReadID_DialogFlag =false;
    private void readDialog(){
        if(ReadID_DialogFlag){
            Log.d("弹窗状态","弹出");
        }else{
            Log.d("弹窗状态","隐藏");
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(TestPage1.this);
        final AlertDialog dialog = builder.setCancelable(false).create();
        View dialogView= LayoutInflater.from(TestPage1.this).inflate(R.layout.dialog__sample_card, null);

        //设置对话框布局
        dialog.setView(dialogView);
        //确认和取消
        Button btnConfirm = (Button) dialogView.findViewById(R.id.btn_Confirm);
        Button btnCancel =(Button)dialogView.findViewById(R.id.btn_Cancel);
        EditText editText =dialogView.findViewById(R.id.dialog_sample_edit);
        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                serialHelper.sendHex("EEA1FF");
                dialog.dismiss();

            }
        });
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                serialHelper.sendHex("EEA2FF");
                Log.d("","");
                dialog.dismiss();
            }
        });


        if(ReadID_DialogFlag){
            if(!isFinishing()){
                dialog.show();
            }
            Log.d("弹窗状态1","弹出");
            ReadID_DialogFlag =false;
        }
        //调整dialog 的View 宽度。
        dialog.getWindow().setLayout(ScreenUtils.getScreenWidth(this)*3/4, LinearLayout.LayoutParams.WRAP_CONTENT);//通过此方式来设置dialog 的宽高
        Window mWindow = dialog.getWindow();
        WindowManager.LayoutParams lp = mWindow.getAttributes();
        lp.x = 0; //新位置X坐标
        lp.y = -50; //新位置Y坐标
        dialog.onWindowAttributesChanged(lp);
    }

    /**
     * @Author
     * @Time 2022/7/20 10:23
     * @Description 进行测试时，测试故障的弹窗提示：
     */
    private boolean dialogFlag;
    private void detectDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final AlertDialog dialog = builder.setCancelable(false).create();
        View dialogView = View.inflate(this, R.layout.dialog_testbug, null);
        //设置对话框布局
        dialog.setView(dialogView);
        //确认和取消
        Button btnConfirm = (Button) dialogView.findViewById(R.id.btn_Confirm);
        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        if(dialogFlag){
            dialog.show();
            dialogFlag=false;
        }
        //调整dialog 的View 宽度。
        dialog.getWindow().setLayout(ScreenUtils.getScreenWidth(this)*3/4, LinearLayout.LayoutParams.WRAP_CONTENT);//通过此方式来设置dialog 的宽高
        Window mWindow = dialog.getWindow();
        WindowManager.LayoutParams lp = mWindow.getAttributes();
        lp.x = 0; //新位置X坐标
        lp.y = -50; //新位置Y坐标
        dialog.onWindowAttributesChanged(lp);
    }


    /**
     * @Author
     * @Time 2022/7/20 10:31
     * @Description 打印时，出现故障提示：
     */
    private boolean Print_DialogFlag =false;
    private void printfDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final AlertDialog dialog = builder.setCancelable(false).create();
        View dialogView = View.inflate(this, R.layout.dialog_print, null);
        //设置对话框布局
        dialog.setView(dialogView);
        //确认和取消
        Button btnConfirm = (Button) dialogView.findViewById(R.id.btn_Confirm);

        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        if(Print_DialogFlag){
            dialog.show();
            Print_DialogFlag =false;
        }
        //调整dialog 的View 宽度。
        dialog.getWindow().setLayout(ScreenUtils.getScreenWidth(this)*3/4, LinearLayout.LayoutParams.WRAP_CONTENT);//通过此方式来设置dialog 的宽高
        Window mWindow = dialog.getWindow();
        WindowManager.LayoutParams lp = mWindow.getAttributes();
        lp.x = 0; //新位置X坐标
        lp.y = -50; //新位置Y坐标
        dialog.onWindowAttributesChanged(lp);
    }




    //*************************************************显示时间**************************************
    public class Task1 implements Runnable {
        @Override
        public void run() {
            getCurrentTime();
            Message message = mHandler.obtainMessage();
            message.what = 0;
            mHandler.sendMessage(message);
            mHandler.postDelayed(this, 1000);
        }
    }
    /**这个表示 完整的日期时间：例如2022-10-13 14:23*/
    private String TimeStr="";
    private int testDay;
    private String  Str_Date,Str_Time;
    private void getCurrentTime() {
        Calendar calendar = Calendar.getInstance();//取得当前时间的年月日 时分秒
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH)+1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        int second = calendar.get(Calendar.SECOND);
        Str_Date=year+"年"+month+"月"+day+"日";

        String Month_Str,Day_Str,date_Str;
        if(day<10){
            Day_Str=0+""+day;
        }else{
            Day_Str=""+day;
        }
        if(month<10){
            Month_Str=0+""+month;
        }else{
            Month_Str=""+month;
        }
        date_Str=year+Month_Str+Day_Str;   //整形的日期时间。
        testDay= Integer.parseInt(date_Str);

        String StrMinute;
        String StrSecond;
        if(minute<10){
            StrMinute=":0"+minute;
        }else {
            StrMinute=":"+minute;
        }
        if(second<10){
            StrSecond=":0"+second;
        }else {
            StrSecond=":"+second;
        }
        Str_Time=hour+""+StrMinute+StrSecond+"";
        TimeStr=year+"-"+month+"-"+day+" "+Str_Time;
    }

    private String getCurrentTime1() {
        Calendar calendar = Calendar.getInstance();//取得当前时间的年月日 时分秒
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH)+1;
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        int second = calendar.get(Calendar.SECOND);
        Str_Date=year+"年"+month+"月"+day+"日";

        String StrMinute;
        String StrSecond;
        if(minute<10){
            StrMinute=":0"+minute;
        }else {
            StrMinute=":"+minute;
        }
        if(second<10){
            StrSecond=":0"+second;
        }else {
            StrSecond=":"+second;
        }
        Str_Time=hour+""+StrMinute+StrSecond+"";
        TimeStr=year+"-"+month+"-"+day+" "+Str_Time;
        return TimeStr;
    }

    private Boolean DetecteFlag=false;
    int i=1;
    /**测试的380个点的电压值字符串*/
    private String DataStr="";
    class MySendThread implements Runnable {
        @Override
        public void run() {
            UploadBean uploadBean =new UploadBean();
            uploadBean.setJigoumingcheng("中日联合医院");
            uploadBean.setYiqileixing("单通道POCT检测仪");
            uploadBean.setYiqibianhao("202202001");
            uploadBean.setYangbenhao(edit_sampleNum.getText().toString());//样本号
            uploadBean.setPicimingcheng("202202001");
            uploadBean.setXingming(nameStr);//姓名
            uploadBean.setNianling(age+ageUnit); //年龄
            uploadBean.setXingbie(GenderStr); //性别
            uploadBean.setLiushuihao(text_index.getText().toString());//流水号
            uploadBean.setShijian(TimeStr); //时间
            uploadBean.setTiaoma(barcodeStr);     //条码值. 可以有
            uploadBean.setXiangmumingcheng(text_Project.getText().toString());    //项目名称
            uploadBean.setZixiangmu(text_Subproject.getText().toString());         //子项目
            uploadBean.setJiancejieguo(text_ConcentrationVvalue.getText().toString());      //浓度值
            uploadBean.setJielun("阴性");
            uploadBean.setDanwei(text_unit.getText().toString());        //单位
            uploadBean.setCeshifanwei("5~6");
            uploadBean.setFanyingzhi("888");        //反应值 ？？/
            uploadBean.setFengzhi("20000");        //峰值
            uploadBean.setZhenduanbumen("化验科2科室");
            uploadBean.setCaozuoyuan("张三");
            uploadBean.setXiangxidizhi(locateStr);      //可以有。
            uploadBean.setCankaofanwei("1~30mmol/L");    //参考范围    ？？？？
            uploadBean.setC("8888");            // C值  ？？？
            uploadBean.setT1("99999");          // T 值？？？
            uploadBean.setYangbenleixing(sprinner_SampleType.getSelectedItem().toString()); // 样本类型
            uploadBean.setJiancedianyazhi(DataStr);

            //发送接受到的电压坐标值。
//            String urlPath = "http://bighang.nat300.top/appPost";  	//URL    这个网址，是我用自己的笔记本作为服务器时的网址。估计应该是不能用了。
           String urlPath="http://116.204.121.150:8080/miniuiex/test/receivefromandroid" ;//这块补充明天单老师给的服务器网址 ************************************
//            String urlPath="http://192.168.110.64:8080/miniuiex_war/test/receivefromandroid";
            // String =
//            String urlPath = "http://"+URLStr.getText().toString();  	//URL
            URL url = null;
            HttpURLConnection coon=null;
            BufferedReader reader = null;
            try {
                url = new URL(urlPath);
                coon = (HttpURLConnection) url.openConnection();
                coon.setRequestMethod("POST");	//请求方式为POST
                coon.setConnectTimeout(5000);   //连接超时
                coon.setRequestProperty("Content-Type", "application/json");     //设置发送的数据为 json 类型，会被添加到http body当中
//                String json = "{\"name\":\""+str+"\"," + "\"bulk\":" + "\"" +SendToNetSt+ "\"}";    //将要发送的花卉数据字符串连接成json格式
//                String json = "{\"name\":\""+str+"\"," + "\"bulk\":" + "\"" +SendToNetSt+ "\"}";
                String json = "{"+
                        "\""+uploadBean.GetJigoumingcheng()+"\":"+ "\"" +uploadBean.getJigoumingcheng()+ "\","+  //机构名称
                        "\""+uploadBean.GetYiqileixing()+"\":" + "\"" +uploadBean.getYiqileixing()+ "\","+          //仪器类型
                        "\""+uploadBean.GetYiqibianhao()+"\":" + "\"" +uploadBean.getYiqibianhao()+ "\","+      //仪器编号
                        "\""+uploadBean.GetYangbenhao()+"\":" + "\"" +uploadBean.getYangbenhao()+ "\","+           //样本号
                        "\""+uploadBean.GetPicimingcheng()+"\":"+ "\""  +uploadBean.getPicimingcheng()+ "\","+    //批次名称
                        "\""+uploadBean.GetNianling()+"\":" + "\"" +uploadBean.getNianling()+ "\","+              //年龄   -----
                        "\""+uploadBean.GetXingbie()+"\":" + "\"" +uploadBean.getXingbie()+ "\","+                 //性别  ---
                        "\""+uploadBean.GetLiushuihao()+"\":"+ "\""  +uploadBean.getLiushuihao()+ "\","+    //流水号
                        "\""+uploadBean.GetShijian()+"\":"+ "\""  +uploadBean.getShijian()+ "\","+    //时间
                        "\""+uploadBean.GetXingming()+"\":"+ "\""  +uploadBean.getXingming()+ "\","+    //姓名： ----
                        "\""+uploadBean.GetTiaoma()+"\":" + "\"" +uploadBean.getTiaoma()+ "\","+    //条码
                        "\""+uploadBean.GetXiangmumingcheng()+"\":" + "\"" +uploadBean.getXiangmumingcheng()+ "\","+     //项目名称
                        "\""+uploadBean.GetZixiangmu()+"\":" + "\"" +uploadBean.getZixiangmu()+ "\","+    //子项目
                        "\""+uploadBean.GetJiancejieguo()+"\":"+ "\""  +uploadBean.getJiancejieguo()+ "\","+     //检测结果
                        "\""+uploadBean.GetJielun()+"\":" + "\"" +uploadBean.getJielun()+ "\","+                    //结论
                        "\""+uploadBean.GetDanwei()+"\":"+ "\""  +uploadBean.getDanwei()+ "\","+    //单位
                        "\""+uploadBean.GetCeshifanwei()+"\":"+ "\""  +uploadBean.getCeshifanwei()+ "\","+    //测试范围
                        "\""+uploadBean.GetFanyingzhi()+"\":"+ "\""  +uploadBean.getFanyingzhi()+ "\","+    //反应值
                        "\""+uploadBean.GetFengzhi()+"\":" + "\"" +uploadBean.getFengzhi()+ "\","+    //峰值
                        "\""+uploadBean.GetZhenduanbumen()+"\":" + "\"" +uploadBean.getZhenduanbumen()+ "\","+    //诊断部门
                        "\""+uploadBean.GetCaozuoyuan()+"\":" + "\"" +uploadBean.getCaozuoyuan()+ "\","+    //操作员
                        "\""+uploadBean.GetXiangxidizhi()+"\":" + "\"" +uploadBean.getXiangxidizhi()+ "\","+     //详细地址
                        "\""+uploadBean.GetCankaofanwei()+"\":" + "\"" +uploadBean.getCankaofanwei()+ "\","+      //参考范围
                        "\""+uploadBean.GetC()+"\":" + "\"" +uploadBean.getC()+ "\","+      //C 值
                        "\""+uploadBean.GetT1()+"\":" + "\"" +uploadBean.getT1()+ "\","+      //T1
                        "\""+uploadBean.GetYangbenleixing()+"\":" + "\"" +uploadBean.getYangbenleixing()+ "\","+      //样本类型
                        "\""+uploadBean.GetJiancedianyazhi()+"\":" + "\"" +uploadBean.getJiancedianyazhi()+ "\""+     //检测电压值
                        "}";
                coon.setRequestProperty("Content-Length", String.valueOf(json.getBytes().length));
                //post请求把数据以流的方式写给服务器，指定请求的输出模式
                coon.setDoOutput(true);
                coon.getOutputStream().write(json.getBytes());
//                coon.getInputStream().read()
                //对获取到的输入流进行读取
                reader =new BufferedReader(new InputStreamReader(coon.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while((line=reader.readLine())!=null){
                    response.append(line);
                }
                showResponse(response.toString());
                int code = coon.getResponseCode();
                if (code == 200) {
                    System.out.println("请求成功");
                    DetecteFlag=true;
                    System.out.println("DetecteFlag");
                } else {
                    System.out.println("请求失败");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }finally {
                if (reader !=null){   //关闭readerbuffer.
                    try {reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }if (coon !=null){  //关闭HTTP连接
                    coon.disconnect();
                }
            }
            //将测试数据保存到数据库中，数据的存储对象为QueryBean类。   好像没什么意义。因为读取数据的时候，直接从ordianaryData中读取数据后，再转换成QueryBean去填充表格。
//            QueryBean queryBean = new QueryBean();
//            queryBean.setBarcodeValue("123456");
//            queryBean.setIndex(text_index.getText().toString());  //流水号
//            queryBean.setSampleId(edit_sampleNum.getText().toString()); //样本号
//            queryBean.setProjectName(text_Project.getText().toString()); //项目名称
//            queryBean.setConcentrationValue(text_ConcentrationVvalue.getText().toString()+text_unit.getText().toString()); //浓度值
//            queryBean.setTestTime(TimeStr); //测试时间
//            queryBean.setPage("");  //
//            queryBean.save();


            OrdinaryData ordinaryData =new OrdinaryData();
            ordinaryData.setSampleId(edit_sampleNum.getText().toString());//样本号
            ordinaryData.setIndex(text_index.getText().toString());  //流水号
            ordinaryData.setBarcodeValue(barcodeStr);//条码值
            ordinaryData.setSampleType(sprinner_SampleType.getSelectedItem().toString()); //样本类型
            ordinaryData.setProjectName(text_Project.getText().toString());   //项目名
            ordinaryData.setItemName(text_Subproject.getText().toString());     //子项目名
            ordinaryData.setConcentrationValue(text_ConcentrationVvalue.getText().toString()); //浓度值
            ordinaryData.setUnit("mmol");//浓度单位
            if(!nameStr.equals("")){}
                ordinaryData.setName(nameStr); //姓名
            if(!age.equals(""))
                ordinaryData.setAge(Integer. parseInt(age)); //年龄
            if (!ageUnit.equals(""))
                ordinaryData.setAgeUint(ageUnit);//年龄单位
            if(!GenderStr.equals(""))
                ordinaryData.setGender(GenderStr);//性别
            ordinaryData.setTestTime(TimeStr);//测试时间
            ordinaryData.setTestDay(testDay);
            ordinaryData.save();

            // 对打印操作需要的参数进行赋值。
            PrintName=nameStr;
            PrintAge=age;
            PrintAgeUint=ageUnit;
            PrintGender=GenderStr;

            nameStr="";
            age="";
            ageUnit="";
            GenderStr="";

//            List<OrdinaryData> OrdinaryDatas= DataSupport.findAll(OrdinaryData.class);
//            Log.d("OrdinaryDatas", String.valueOf(OrdinaryDatas.size()));
//            for (OrdinaryData ordinarydata:OrdinaryDatas) {
//             Log.d("ordinarydata",ordinarydata.toString());
//            }
            Message message = new Message();   //测试成功更新当前页面流水号。
            message.what=2;
            mHandler.sendMessage(message);
        }
    }

    /**
     * @Author
     * @Time 2022/10/12 20:11
     * @Description 打印接收到的服务器的数据。
     */
    private void showResponse(final String response) {
        runOnUiThread(new Runnable() {
                          @Override public void run() {
                              // 在这里进行UI操作，将结果显示到界面上
//                responseText.setText(response);
                              Log.d("接收到的指令：",response);
                          }
                      }
        );
    }
}