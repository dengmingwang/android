package com.example.singlepoct.Bean;

import org.litepal.crud.DataSupport;
/**
 * **************************
 * 项目名称：SinglePOCT
 *
 * @Author BigHang
 * 创建时间：2022/7/20  9:02
 * 用途:这个类使用来存储历史查询中的常规数据。参数尾缀标记为 ”1",确定从上位机获得。
 * **************************
 */
public class OrdinaryData extends DataSupport{
    /**流水号  1*/
    private String index;
    /**样本号  1*/
    private String sampleId;
    /**样本类型  1*/
    private String sampleType;
    /**条码值*/
    private String barcodeValue;
    /**测试项目*/
    private String  projectName;
    /**子项目名称*/
    private String  ItemName;
    /**浓度值，也就是结果值*/
    private String concentrationValue;
    /**浓度的单位值*/
    private String unit;
    /**峰值点1 横纵坐标*/
    private int peakX1,getPeakY1;
    /**峰值点1 横纵坐标*/
    private int peakX2,getPeakY2;
    /**测试时间  1 */
    private String testTime;
    /**测试日期  */
    private int TestDay;   //用来做日期筛查排序。
    //_______________ 高级信息 ______________________
    /**姓名 1*/
    private String name;
    /**性别 1 */
    private String gender;
    /**年龄 1*/
    private int age;
    /**年龄单位 1*/
    private String ageUint;

    public String  getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public String getSampleId() {
        return sampleId;
    }

    public void setSampleId(String sampleId) {
        this.sampleId = sampleId;
    }

    public String getSampleType() {
        return sampleType;
    }

    public void setSampleType(String sampleType) {
        this.sampleType = sampleType;
    }

    public String getBarcodeValue() {
        return barcodeValue;
    }

    public void setBarcodeValue(String barcodeValue) {
        this.barcodeValue = barcodeValue;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getItemName() {
        return ItemName;
    }

    public void setItemName(String itemName) {
        ItemName = itemName;
    }

    public String getConcentrationValue() {
        return concentrationValue;
    }

    public void setConcentrationValue(String concentrationValue) {
        this.concentrationValue = concentrationValue;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public int getPeakX1() {
        return peakX1;
    }

    public void setPeakX1(int peakX1) {
        this.peakX1 = peakX1;
    }

    public int getGetPeakY1() {
        return getPeakY1;
    }

    public void setGetPeakY1(int getPeakY1) {
        this.getPeakY1 = getPeakY1;
    }

    public int getPeakX2() {
        return peakX2;
    }

    public void setPeakX2(int peakX2) {
        this.peakX2 = peakX2;
    }

    public int getGetPeakY2() {
        return getPeakY2;
    }

    public void setGetPeakY2(int getPeakY2) {
        this.getPeakY2 = getPeakY2;
    }

    public String getTestTime() {
        return testTime;
    }

    public void setTestTime(String testTime) {
        this.testTime = testTime;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getAgeUint() {
        return ageUint;
    }

    public void setAgeUint(String ageUint) {
        this.ageUint = ageUint;
    }


    public int getTestDay() {
        return TestDay;
    }

    public void setTestDay(int testDay) {
        TestDay = testDay;
    }


    @Override
    public String toString() {
        return "OrdinaryData{" +
                "index=" + index +
                ", sampleId='" + sampleId + '\'' +
                ", sampleType='" + sampleType + '\'' +
                ", barcodeValue='" + barcodeValue + '\'' +
                ", projectName='" + projectName + '\'' +
                ", ItemName='" + ItemName + '\'' +
                ", concentrationValue=" + concentrationValue +
                ", unit='" + unit + '\'' +
                ", peakX1=" + peakX1 +
                ", getPeakY1=" + getPeakY1 +
                ", peakX2=" + peakX2 +
                ", getPeakY2=" + getPeakY2 +
                ", testTime='" + testTime + '\'' +
                ", name='" + name + '\'' +
                ", gender='" + gender + '\'' +
                ", age=" + age +
                ", ageUint='" + ageUint + '\'' +
                '}';
    }
}
