package com.example.singlepoct.Bean;

import java.util.Date;

/**
 * **************************
 * 项目名称：SinglePOCT
 *
 * @Author BigHang
 * 创建时间：2022/10/11  15:50
 * 用途: 用来上传检测之后的指标参数。
 * **************************
 */
public class UploadBean {

//    @ExcelProperty("机构名称")
    private String jigoumingcheng="";
//    @ExcelProperty("仪器类型")
    private String yiqileixing="";
//    @ExcelProperty("仪器编号")
    private String yiqibianhao="";
//    @ExcelProperty("样本号")
    private String yangbenhao="";
//    @ExcelProperty("批次名称(编号)")
    private String picimingcheng="";
//    @ExcelProperty("年龄")
    private String nianling="";
//    @ExcelProperty("性别")
    private String xingbie="";
//    @ExcelProperty("流水号")
    private String liushuihao="";
//    @DateTimeFormat("yyyy-MM-dd HH:mm:ss")
//    @ExcelProperty("时间")
    private String shijian="";
    //    @ExcelProperty("姓名")
    private String xingming="";
//    @ExcelProperty("条码")
    private String tiaoma="";
//    @ExcelProperty("项目名称")
    private String xiangmumingcheng="";
//    @ExcelProperty("子项目")
    private String zixiangmu="";
//    @ExcelProperty("检测结果")
    private String jiancejieguo="";
//    @ExcelProperty("结论")
    private String jielun="";
//    @ExcelProperty("单位")
    private String danwei="";
//    @ExcelProperty("测试范围")
    private String ceshifanwei="";
//    @ExcelProperty("反应值")
    private String fanyingzhi="";
//    @ExcelProperty("峰值")
    private String fengzhi="";
//    @ExcelProperty("诊断部门")
    private String zhenduanbumen="";
//    @ExcelProperty("操作员")
    private String caozuoyuan="";
//    @ExcelProperty("详细地址")
    private String xiangxidizhi="";
//    @ExcelProperty("参考范围")
    private String cankaofanwei="";
//    @ExcelProperty("C值")
    private String c="";
//    @ExcelProperty("T1")
    private String t1="";
//    @ExcelProperty("样本类型")
    private String yangbenleixing="";
//    @ExcelProperty("检测的电压值数据")
    private String jiancedianyazhi="";



    public String getJigoumingcheng() {
        return jigoumingcheng;
    }

    public void setJigoumingcheng(String jigoumingcheng) {
        this.jigoumingcheng = jigoumingcheng;
    }

    public String getYiqileixing() {
        return yiqileixing;
    }

    public void setYiqileixing(String yiqileixing) {
        this.yiqileixing = yiqileixing;
    }

    public String getYiqibianhao() {
        return yiqibianhao;
    }

    public void setYiqibianhao(String yiqibianhao) {
        this.yiqibianhao = yiqibianhao;
    }

    public String getYangbenhao() {
        return yangbenhao;
    }

    public void setYangbenhao(String yangbenhao) {
        this.yangbenhao = yangbenhao;
    }

    public String getPicimingcheng() {
        return picimingcheng;
    }

    public void setPicimingcheng(String picimingcheng) {
        this.picimingcheng = picimingcheng;
    }

    public String getNianling() {
        return nianling;
    }

    public void setNianling(String nianling) {
        this.nianling = nianling;
    }

    public String getXingbie() {
        return xingbie;
    }

    public void setXingbie(String xingbie) {
        this.xingbie = xingbie;
    }

    public String getLiushuihao() {
        return liushuihao;
    }

    public void setLiushuihao(String liushuihao) {
        this.liushuihao = liushuihao;
    }

    public String getShijian() {
        return shijian;
    }

    public void setShijian(String shijian) {
        this.shijian = shijian;
    }

    public String getXingming() {
        return xingming;
    }

    public void setXingming(String xingming) {
        this.xingming = xingming;
    }

    public String getTiaoma() {
        return tiaoma;
    }

    public void setTiaoma(String tiaoma) {
        this.tiaoma = tiaoma;
    }

    public String getXiangmumingcheng() {
        return xiangmumingcheng;
    }

    public void setXiangmumingcheng(String xiangmumingcheng) {
        this.xiangmumingcheng = xiangmumingcheng;
    }

    public String getZixiangmu() {
        return zixiangmu;
    }

    public void setZixiangmu(String zixiangmu) {
        this.zixiangmu = zixiangmu;
    }

    public String getJiancejieguo() {
        return jiancejieguo;
    }

    public void setJiancejieguo(String jiancejieguo) {
        this.jiancejieguo = jiancejieguo;
    }

    public String getJielun() {
        return jielun;
    }

    public void setJielun(String jielun) {
        this.jielun = jielun;
    }

    public String getDanwei() {
        return danwei;
    }

    public void setDanwei(String danwei) {
        this.danwei = danwei;
    }

    public String getCeshifanwei() {
        return ceshifanwei;
    }

    public void setCeshifanwei(String ceshifanwei) {
        this.ceshifanwei = ceshifanwei;
    }

    public String getFanyingzhi() {
        return fanyingzhi;
    }

    public void setFanyingzhi(String fanyingzhi) {
        this.fanyingzhi = fanyingzhi;
    }

    public String getFengzhi() {
        return fengzhi;
    }

    public void setFengzhi(String fengzhi) {
        this.fengzhi = fengzhi;
    }

    public String getZhenduanbumen() {
        return zhenduanbumen;
    }

    public void setZhenduanbumen(String zhenduanbumen) {
        this.zhenduanbumen = zhenduanbumen;
    }

    public String getCaozuoyuan() {
        return caozuoyuan;
    }

    public void setCaozuoyuan(String caozuoyuan) {
        this.caozuoyuan = caozuoyuan;
    }

    public String getXiangxidizhi() {
        return xiangxidizhi;
    }

    public void setXiangxidizhi(String xiangxidizhi) {
        this.xiangxidizhi = xiangxidizhi;
    }

    public String getCankaofanwei() {
        return cankaofanwei;
    }

    public void setCankaofanwei(String cankaofanwei) {
        this.cankaofanwei = cankaofanwei;
    }

    public String getC() {
        return c;
    }

    public void setC(String c) {
        this.c = c;
    }

    public String getT1() {
        return t1;
    }

    public void setT1(String t1) {
        this.t1 = t1;
    }

    public String getYangbenleixing() {
        return yangbenleixing;
    }

    public void setYangbenleixing(String yangbenleixing) {
        this.yangbenleixing = yangbenleixing;
    }

    public String getJiancedianyazhi() {
        return jiancedianyazhi;
    }

    public void setJiancedianyazhi(String jiancedianyazhi) {
        this.jiancedianyazhi = jiancedianyazhi;
    }

    @Override
    public String toString() {
        return "UploadBean{" +
                "jigoumingcheng='" + jigoumingcheng + '\'' +
                ", yiqileixing='" + yiqileixing + '\'' +
                ", yiqibianhao='" + yiqibianhao + '\'' +
                ", yangbenhao='" + yangbenhao + '\'' +
                ", picimingcheng='" + picimingcheng + '\'' +
                ", nianling='" + nianling + '\'' +
                ", xingbie='" + xingbie + '\'' +
                ", liushuihao='" + liushuihao + '\'' +
                ", shijian='" + shijian + '\'' +
                ", xingming='" + xingming + '\'' +
                ", tiaoma='" + tiaoma + '\'' +
                ", xiangmumingcheng='" + xiangmumingcheng + '\'' +
                ", zixiangmu='" + zixiangmu + '\'' +
                ", jiancejieguo='" + jiancejieguo + '\'' +
                ", jielun='" + jielun + '\'' +
                ", danwei='" + danwei + '\'' +
                ", ceshifanwei='" + ceshifanwei + '\'' +
                ", fanyingzhi='" + fanyingzhi + '\'' +
                ", fengzhi='" + fengzhi + '\'' +
                ", zhenduanbumen='" + zhenduanbumen + '\'' +
                ", caozuoyuan='" + caozuoyuan + '\'' +
                ", xiangxidizhi='" + xiangxidizhi + '\'' +
                ", cankaofanwei='" + cankaofanwei + '\'' +
                ", c='" + c + '\'' +
                ", t1='" + t1 + '\'' +
                ", yangbenleixing='" + yangbenleixing + '\'' +
                ", jiancedianyazhi='" + jiancedianyazhi + '\'' +
                '}';
    }

    //--------------------------------------- 3.获取各个信息的参数名称：
    public String GetJigoumingcheng() {
        return "jigoumingcheng";
    }

    public String GetYiqileixing() {
        return "yiqileixing";
    }

    public String GetYiqibianhao() {
        return "yiqibianhao";
    }

    public String GetYangbenhao() {
        return "yangbenhao";
    }

    public String GetPicimingcheng() {
        return "picimingcheng";
    }

    public String GetNianling() {
        return "nianling";
    }

    public String GetXingbie() {
        return "xingbie";
    }

    public String GetLiushuihao() {
        return "liushuihao";
    }

    public String GetShijian() {
        return "shijian";
    }

    public String GetXingming() { return "xingming"; }

    public String GetTiaoma() {
        return "tiaoma";
    }

    public String GetXiangmumingcheng() {
        return "xiangmumingcheng";
    }

    public String GetZixiangmu() {
        return "zixiangmu";
    }

    public String GetJiancejieguo() {
        return "jiancejieguo";
    }

    public String GetJielun() {
        return "jielun";
    }

    public String GetDanwei() {
        return "danwei";
    }

    public String GetCeshifanwei() {
        return "ceshifanwei";
    }

    public String GetFanyingzhi() {
        return "fanyingzhi";
    }

    public String GetFengzhi() {
        return "fengzhi";
    }

    public String GetZhenduanbumen() {
        return "zhenduanbumen";
    }

    public String GetCaozuoyuan() {
        return "caozuoyuan";
    }

    public String GetXiangxidizhi() {
        return "xiangxidizhi";
    }

    public String GetCankaofanwei() {
        return "cankaofanwei";
    }

    public String GetC() {
        return "c";
    }

    public String GetT1() {
        return "t1";
    }

    public String GetYangbenleixing() {
        return "yangbenleixing";
    }

    public String GetJiancedianyazhi() {
        return "jiancedianyazhi";
    }


}
