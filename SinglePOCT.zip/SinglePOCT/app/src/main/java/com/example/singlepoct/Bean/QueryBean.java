package com.example.singlepoct.Bean;

import android.widget.CheckBox;

import com.bin.david.form.annotation.SmartColumn;
import com.bin.david.form.annotation.SmartTable;

import org.litepal.crud.DataSupport;

/**
 * **************************
 * 项目名称：SinglePOCT
 *
 * @Author BigHang
 * 创建时间：2022/7/14  16:18
 * 用途:用于建立表格的样本类信息
 * **************************
 */

public class QueryBean extends DataSupport {
    /***/
    private CheckBox checkBox;
    private Boolean checkBoxflag=false;
    private String index;
    /**样本号*/
    private String  sampleId;
    /**条码值*/
    private String barcodeValue;
    /**项目名*/
    private String  projectName;
    /**浓度值*/
    private String concentrationValue;
    /**单位*/
    private String unit;
    /**样本类型*/
    private String sampleType;
    /**测试时间*/
    private String testTime;
    /**姓名*/
    private String name;
    /**性别*/
    private String gender;
    /**年龄*/
    private String age;
    /**页码显示区的占位符*/
    private String page;

    public QueryBean() {
    }

    public QueryBean(String index, String  sampleId, String barcodeValue, String projectName, String concentrationValue, String unit, String sampleType, String testTime, String name, String gender, String age, String page) {
        this.index = index;
        this.sampleId = sampleId;
        this.barcodeValue = barcodeValue;
        this.projectName = projectName;
        this.concentrationValue = concentrationValue;
        this.unit = unit;
        this.sampleType = sampleType;
        this.testTime = testTime;
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.page = page;
    }

    public QueryBean(CheckBox checkBox, String index, String sampleId, String barcodeValue, String projectName, String concentrationValue, String unit, String sampleType, String testTime, String name, String gender, String age, String page) {
        this.checkBox = checkBox;
        this.index = index;
        this.sampleId = sampleId;
        this.barcodeValue = barcodeValue;
        this.projectName = projectName;
        this.concentrationValue = concentrationValue;
        this.unit = unit;
        this.sampleType = sampleType;
        this.testTime = testTime;
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.page = page;
    }

    public QueryBean(CheckBox checkBox, String index, String sampleId, String projectName, String concentrationValue, String testTime, String page) {
        this.checkBox = checkBox;
        this.index = index;
        this.sampleId = sampleId;
        this.projectName = projectName;
        this.concentrationValue = concentrationValue;
        this.testTime = testTime;
        this.page = page;
    }


    public Boolean getCheckBoxflag() {
        return checkBoxflag;
    }

    public void setCheckBoxflag(Boolean checkBoxflag) {
        this.checkBoxflag = checkBoxflag;
    }

    public CheckBox getCheckBox() {
        return checkBox;
    }

    public void setCheckBox(CheckBox checkBox) {
        this.checkBox = checkBox;
    }

    public String getIndex() {
        return index;
    }



    public void setIndex(String index) {
        this.index = index;
    }

    public String getSampleId() {
        return sampleId;
    }

    public void setSampleId(String sampleId) {
        this.sampleId = sampleId;
    }

    public String getBarcodeValue() {
        return barcodeValue;
    }

    public void setBarcodeValue(String barcodeValue) {
        this.barcodeValue = barcodeValue;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getConcentrationValue() {
        return concentrationValue;
    }

    public void setConcentrationValue(String concentrationValue) {
        this.concentrationValue = concentrationValue;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getSampleType() {
        return sampleType;
    }

    public void setSampleType(String sampleType) {
        this.sampleType = sampleType;
    }

    public String getTestTime() {
        return testTime;
    }

    public void setTestTime(String testTime) {
        this.testTime = testTime;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAge() {
        return age;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public String getPage() {
        return page;
    }

    public void setPage(String page) {
        this.page = page;
    }

    @Override
    public String toString() {
        return "QueryBean{" +
                "checkBox=" + checkBox +
                ", checkBoxflag=" + checkBoxflag +
                ", index=" + index +
                ", sampleId=" + sampleId +
                ", barcodeValue=" + barcodeValue +
                ", projectName='" + projectName + '\'' +
                ", concentrationValue=" + concentrationValue +
                ", unit='" + unit + '\'' +
                ", sampleType='" + sampleType + '\'' +
                ", testTime='" + testTime + '\'' +
                ", name='" + name + '\'' +
                ", gender='" + gender + '\'' +
                ", age=" + age +
                ", page='" + page + '\'' +
                '}';
    }
}
