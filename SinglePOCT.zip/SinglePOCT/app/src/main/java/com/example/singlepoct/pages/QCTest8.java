package com.example.singlepoct.pages;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.singlepoct.R;

public class QCTest8 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qctest8);
    }
}