package com.example.singlepoct.pages;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.singlepoct.R;
import com.example.singlepoct.utils.OutputAdapter;
import com.example.singlepoct.utils.ScreenUtils;
import com.example.singlepoct.utils.Tools;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SettingPage5 extends AppCompatActivity implements View.OnClickListener, TimePicker.OnTimeChangedListener, DatePicker.OnDateChangedListener, CompoundButton.OnCheckedChangeListener {


    private Handler mHandler=new Handler(){
        @Override
        public void handleMessage(Message msg){
            switch(msg.what) {
                case 0:
                    text_Date.setText(Str_Date);
                    text_time.setText(Str_Time);
                    break;
                case 1:
                    break;
                default:
                    break;
            }
        }

    };

    private Tools tools;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting_page5);
        BindComponent();
        tools=new Tools();
        Task1 task1= new Task1();
        mHandler.postDelayed(task1,0);
        viewShow = LayoutInflater.from(this).inflate(R.layout.config_page1 , linearLayout1 , true) ;
    }

    private Button Btn_CompanyView,Btn_LIS,Btn_Test,Btn_System,Btn_Version,Btn_Output;
    private Button btn_TotalBack;
    LinearLayout linearLayout1;
    private TextView text_Date,text_time;


    private void BindComponent() {

    linearLayout1=findViewById(R.id.LinearLayout_Setting5);

    Btn_CompanyView=findViewById(R.id.CompanyView);
    Btn_CompanyView.setOnClickListener(this);

    Btn_LIS=findViewById(R.id.LIS_Config);
    Btn_LIS.setOnClickListener(this);

    Btn_Test=findViewById(R.id.Test_Config);
    Btn_Test.setOnClickListener(this);

    Btn_System=findViewById(R.id.System_Cofing);
    Btn_System.setOnClickListener(this);

    Btn_Version=findViewById(R.id.Version_Info);
    Btn_Version.setOnClickListener(this);

    btn_TotalBack=findViewById(R.id.Menu_Back);
    btn_TotalBack.setOnClickListener(this);

    Btn_Output=findViewById(R.id.OutputSetting);
    Btn_Output.setOnClickListener(this);

    text_Date=findViewById(R.id.Text_Date);
    text_time=findViewById(R.id.Text_Time);



    }

    Intent intent;
    View viewShow;
    @Override
    public void onClick(View view) {
        int id = view.getId();
        switch(id){
            case R.id.CompanyView:
                linearLayout1.removeAllViews();
                viewShow = LayoutInflater.from(this).inflate(R.layout.config_page1 , linearLayout1 , true) ;
//                btnTest1=viewShow.findViewById(R.id.btn_test1);
////                btnTest1.setOnClickListener(this);
                break;
            case R.id.LIS_Config:
                linearLayout1.removeAllViews();
                viewShow = LayoutInflater.from(this).inflate(R.layout.config_page2 , linearLayout1 , true) ;
                Config2Bind();
                break;
            case R.id.Test_Config:
                linearLayout1.removeAllViews();
                viewShow = LayoutInflater.from(this).inflate(R.layout.config_page3 , linearLayout1 , true) ;
                break;
            case R.id.System_Cofing:
                linearLayout1.removeAllViews();
                viewShow = LayoutInflater.from(this).inflate(R.layout.config_page4 , linearLayout1 , true) ;
                Config4Bind();
                break;
            case R.id.Version_Info:
                linearLayout1.removeAllViews();
                viewShow = LayoutInflater.from(this).inflate(R.layout.config_page5 , linearLayout1 , true) ;
                break;
            case R.id.Menu_Back:
                intent=new Intent(SettingPage5.this,MainActivity.class);
                startActivity(intent);
                break;
            case R.id.NextItem:
                Log.d("当前点击","NextItem");
                String str=baudRate_Select.getSelectedItem().toString();
                Log.d("str",str);
                for(int i=0;i<starArray1.length;i++){
                    if(starArray1[i].equals(baudRate_Select.getSelectedItem().toString()))
                    {
                        Log.d("i", String.valueOf(i));
                        if(i==starArray1.length-1){
                            baudRate_Select.setSelection(0);
                        }else{
                            baudRate_Select.setSelection(i+1);
                        }
                        break;
                    }

                }
                break;
            case R.id.Save_Config2:
                SaveConfig2();
                break;
            case R.id.Date_config4:
                Log.d("当前设置","Data");
                dialogFlag=true;
                showMyDate();
                break;
            case R.id.Time_config4:
                Log.d("当前设置","Time");
                dialogFlag=true;
                showMyTime();
                break;
            case R.id.Config4_Save:
                Config4_Save();
                break;
            case R.id.OutputSetting:
                Log.d("当前设置","OutputSetting");
                linearLayout1.removeAllViews();
                viewShow = LayoutInflater.from(this).inflate(R.layout.config_page6 , linearLayout1 , true) ;
                Config6Bind();
                break;
                //一下几个是设置输出结果排序。
            case R.id.SingleRight:
                Log.d("111111","1111111");
                if(SendIndex!=-1){
                    SelectList.add(SendList.get(SendIndex));
                    SendList.remove(SendIndex);
                    SendIndex=-1;
                    ChangeListView();
                }
                break;
            case R.id.SingleLeft:
                Log.d("22222","222222");
                if(SelectIndex!=-1){
                    SendList.add(SelectList.get(SelectIndex));
                    SelectList.remove(SelectIndex);
                    SelectIndex=-1;
                    ChangeListView();
                }
                break;
            case R.id.TotalLeft:     //表示  <<  :将右边列表的数据全部移到左边。
                SelectList.clear();
                SendList.clear();
                for (int i=0;i< data.length;i++){
                    SendList.add(data[i]);
                }
                ChangeListView();
                break;
            case R.id.TotalRight:    //表示 >>  将左边列表数据全部移到右边。
                for (int i=0;i<SendList.size();i++)
                {
                    SelectList.add(SendList.get(i));
                }
                SendList.clear();
                ChangeListView();
                break;
            case R.id.printf:
                PrintStr="";
                for(int i=0;i<SelectList.size();i++){
                    String str1= map.get(SelectList.get(i));
                    PrintStr=PrintStr+str1+"\r\n";
                }
                textView.setText(PrintStr);
                break;


            default:
                break;
        }
    }





    //*******************************config4 系统设置界面 ***********************************
    private Button btn_Save;
    private Boolean showDateFlag=false;
    private EditText turnOffScreen;
    private Spinner switchUnits;
    private TextView text_MemorySpace;
    private Switch switchBuzzer;
    String[] starArray3 = {"Sec", "Min"};
    //绑定系统界面的组件

    private void Config4Bind() {

        showTime=findViewById(R.id.Time_config4);
        showTime.setOnClickListener(this);

        showDate=findViewById(R.id.Date_config4);
        showDate.setOnClickListener(this);

        btn_Save=findViewById(R.id.Config4_Save);
        btn_Save.setOnClickListener(this);

        showDateFlag=true;  //??

        turnOffScreen=findViewById(R.id.TurnOffScreen);
        turnOffScreen.setOnClickListener(this);

        switchUnits=findViewById(R.id.UnitSpinner);
        tools.initSpinner(this,switchUnits,starArray3);

        text_MemorySpace=findViewById(R.id.MemorySpace);
        int num = (int)(tools.GetAvailableSize()*100/tools.getTotalInternalMemorySize());

        String str = String.valueOf(tools.GetAvailableSize());
        text_MemorySpace.setText(String.valueOf(num));

        switchBuzzer=findViewById(R.id.BuzzerSwitch);
        switchBuzzer.setOnCheckedChangeListener(this);
    }



    private void Config4_Save() {

        Intent intent=new Intent();
        intent.setAction("ACTION_UPDATE_TIME");
        Log.d("设置日期时间：",ZYear+"-"+ZMonth+"-"+ZDay+"-"+ZHour+"-"+ZMin);
        ZMonth++;
        if(ZMonth<10){
            intent.putExtra("cmd",ZYear+"-0"+ZMonth+"-"+ZDay+"-"+ZHour+"-"+ZMin+"-"+"00");
        }else
        intent.putExtra("cmd",ZYear+"-"+ZMonth+"-"+ZDay+"-"+ZHour+"-"+ZMin+"-"+"00");
//        intent.putExtra("cmd","2016-05-26-19-28-32");
        sendBroadcast(intent,null);
    }
//*******************************config4 系统设置界面 ***********************************


    //*******************************config2 LiS 设置界面 *************************
    private EditText localIp1,localIp2,localIp3,localIp4;
    private EditText remoteIp1,remoteIp2,remoteIp3,remoteIp4;
    private EditText IP_Port;
    private Switch switch_Lis;
    private Spinner baudRate_Select, interface_Select;
    private Button btn_Next,btn_save_config2;
    String[] starArray1 = {"2400", "4800", "19200", "38400","57600","115200"};//用来表示孔位字符串数组     孔位的数字中间是不留空格。
    String[] starArray2 = {"IP通信", "串口通信"};//用来表示孔位字符串数组     孔位的数字中间是不留空格。
    private void Config2Bind() {
        //IP设置：
        localIp1=findViewById(R.id.Local_IP1);
        localIp2=findViewById(R.id.Local_IP2);
        localIp3=findViewById(R.id.Local_IP3);
        localIp4=findViewById(R.id.Local_IP4);

        remoteIp1=findViewById(R.id.Remote_IP1);
        remoteIp2=findViewById(R.id.Remote_IP2);
        remoteIp3=findViewById(R.id.Remote_IP3);
        remoteIp4=findViewById(R.id.Remote_IP4);
        IP_Port=findViewById(R.id.Port_Select);

        //串口设置：
        baudRate_Select=findViewById(R.id.BaudRate_Select);
        Tools.initSpinner(this,baudRate_Select,starArray1);


        interface_Select=findViewById(R.id.Interface_Select);
        Tools.initSpinner(this,interface_Select,starArray2);

        btn_Next = findViewById(R.id.NextItem);
        btn_Next.setOnClickListener(this);
        btn_save_config2=findViewById(R.id.Save_Config2);
        btn_save_config2.setOnClickListener(this);

        switch_Lis=findViewById(R.id.LIS_Switch);
        switch_Lis.setOnCheckedChangeListener(this);
    }


    /**
     * @Author
     * @Time 2022/7/19 11:00
     * @Description 对数据接口进行保存：
     */
    private void SaveConfig2() {




    }
//*******************************config2 LiS 设置界面 *************************



//*******************************config3 测试界面-1  ***********************

    private EditText edit_Index,edit_IndexLength,edit_SaveDays;
    private Switch switch_Aglin,switch_Print,switch_AutoTest,switch_Juge;
    private Button Save_Config3;
    private void Config3Bind(){

        edit_Index=findViewById(R.id.Index_config3);
        edit_IndexLength=findViewById(R.id.IndexLength_config3);
        edit_SaveDays=findViewById(R.id.SaveDays_config3);

        switch_Aglin=findViewById(R.id.SwitchAlign_Config3);
        switch_Aglin.setOnCheckedChangeListener(this);

        switch_Print=findViewById(R.id.SwitchPrint_Config3);
        switch_Print.setOnCheckedChangeListener(this);
        switch_AutoTest=findViewById(R.id.SwitchAutoTest_Config3);
        switch_AutoTest.setOnCheckedChangeListener(this);

        switch_Juge=findViewById(R.id.SwitchJuge_Config3);
        switch_Juge.setOnCheckedChangeListener(this);
        Save_Config3=findViewById(R.id.Save_Config3);
    }






//*******************************config3 测试界面-2  ***********************
@Override
public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
    switch (compoundButton.getId()){
        case R.id.BuzzerSwitch:
            if (b){
                Log.e("TAG", "开启 蜂鸣器");
            }else {
                Log.e("TAG", "关闭 蜂鸣器");
            }
            break;
        case R.id.LIS_Switch:
            if (b){
                Log.e("TAG", "开启 LIS接口");
            }else {
                Log.e("TAG", "关闭 LIS接口");
            }
            break;
        case R.id.SwitchAlign_Config3:
            if (b){
                Log.e("TAG", "开启 流水号对齐");
            }else {
                Log.e("TAG", "关闭 流水号对齐");
            }
            break;
        case R.id.SwitchPrint_Config3:
            if (b){
                Log.e("TAG", "开启 即时打印");
            }else {
                Log.e("TAG", "关闭 即时打印");
            }
            break;
        case R.id.SwitchAutoTest_Config3:
            if (b){
                Log.e("TAG", "开启 自动测试");
            }else {
                Log.e("TAG", "关闭 自动测试");
            }
            break;
        case R.id.SwitchJuge_Config3:
            if (b){
                Log.e("TAG", "开启 加卡判断");
            }else {
                Log.e("TAG", "关闭 加卡判断");
            }
            break;


    }

}


//




    public class Task1 implements Runnable {
        @Override
        public void run() {
            getCurrentTime();
            Message message = mHandler.obtainMessage();
            message.what = 0;
            mHandler.sendMessage(message);
            mHandler.postDelayed(this, 1000);
        }
    }
    private String Str_date,Str_time,strTime,strDate;
    private String  Str_Date,Str_Time;
    private void getCurrentTime() {
//        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss");
//        Date date = new Date(System.currentTimeMillis());
//        return simpleDateFormat.format(date);
        Calendar calendar = Calendar.getInstance();//取得当前时间的年月日 时分秒
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        int second = calendar.get(Calendar.SECOND);
        Str_Date=year+"年"+month+"月"+day+"日";

        String StrMinute;
        String StrSecond;
        if(minute<10){
            StrMinute=":0"+minute;
        }else {
            StrMinute=":"+minute;
        }
        if(second<10){
            StrSecond=":0"+second;
        }else {
            StrSecond=":"+second;
        }
        Str_Time=hour+StrMinute+StrSecond+"";
        if(showDateFlag){
            strDate=year+":"+month+":"+day;
            strTime=Str_Time;
            showDate.setText(strDate);
            showTime.setText(strTime);
            showDateFlag=false;
        }
    }






//*************************************************   设置系统时间 Start ***************************************
    @Override
    public void onDateChanged(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {
        // TODO Auto-generated method stub
        TYear=year;
        TMonth=monthOfYear+1;
        TDay=dayOfMonth;
    }
    @Override
    public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
        // TODO Auto-generated method stub
        THour=hourOfDay;
        TMin=minute;
    }



    /**定义时间日期组件*/
    private DatePicker datePicker1;
    private TimePicker timePicker1;
    /**新建年月日中间变量*/
    private int TYear,TMonth,TDay,THour,TMin,TSecond;
    /**年月日最终的接收变量*/
    private int ZYear,ZMonth,ZDay,ZHour,ZMin;
    private boolean dialogFlag;
    private TextView showTime,showDate;

    /**设置时间小弹窗*/
    private void showMyTime() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final AlertDialog dialog = builder.setCancelable(false).create();
        View dialogView = View.inflate(this, R.layout.dialog_time, null);
        //设置对话框布局
        dialog.setView(dialogView);
        //绑定组件，并设置默认参数值：
//        CurStep=(TextView)dialogView.findViewById(R.id.textView);
        timePicker1=(TimePicker) dialogView.findViewById(R.id.TimePicker1);
        timePicker1.setIs24HourView(true);
        //设置时间被改变后的监听时间
        timePicker1.setOnTimeChangedListener(this);
        Button btnConfirm = (Button) dialogView.findViewById(R.id.btn_login);
        Button btnCancel = (Button) dialogView.findViewById(R.id.btn_Confirm);

        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ZHour=THour;
                ZMin=TMin;
                showTime.setText(ZHour+":"+ZMin+":00");
                Log.d("zhour", String.valueOf(ZHour));
                dialog.dismiss();
            }

        });
        //点击取消，直接退出当前参数设置对话框，同时将参数设置的中间量清零。
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        if(dialogFlag){
            dialog.show();
            dialogFlag=false;
        }else {

        }
        //调整dialog 的View 宽度。
        dialog.getWindow().setLayout(ScreenUtils.getScreenWidth(this)*2/3, LinearLayout.LayoutParams.WRAP_CONTENT);//通过此方式来设置dialog 的宽高
    }

    /**设置日期小弹窗*/
    private void showMyDate() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final AlertDialog dialog = builder.setCancelable(false).create();
        View dialogView = View.inflate(this, R.layout.dialog_date, null);
        //设置对话框布局
        dialog.setView(dialogView);
        //绑定组件，并设置默认参数值：
        datePicker1=(DatePicker) dialogView.findViewById(R.id.datePicker1);
        //初始化日期，并设置日期被改变后的监听事件
        datePicker1.init(2021, 8, 7, this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            datePicker1.setOnDateChangedListener(this);
        }
        Button btnConfirm = (Button) dialogView.findViewById(R.id.btn_login);
        Button btnCancel = (Button) dialogView.findViewById(R.id.btn_Confirm);

        btnConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ZYear=TYear;
                ZMonth=TMonth;
                ZDay=TDay;
                showDate.setText(ZYear+"-"+ZMonth+"-"+ZDay+"");
                dialog.dismiss();
            }

        });
        //点击取消，直接退出当前参数设置对话框，同时将参数设置的中间量清零。
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dialog.dismiss();
            }
        });
        if(dialogFlag){
            dialog.show();
            dialogFlag=false;
        }else {

        }
        //调整dialog 的View 宽度。
        dialog.getWindow().setLayout(ScreenUtils.getScreenWidth(this)*2/3, LinearLayout.LayoutParams.WRAP_CONTENT);//通过此方式来设置dialog 的宽高
    }


    //*************************************************   设置系统时间 End ***************************************



    //*******************************config6 设置结果输出排序界面-Start ***********************************

    private String[] data = { "name", "age", "gender", "serial number", "sample number", "result"};
    private List<String> SelectList=new ArrayList<>();
    private List<String> SendList=new ArrayList<>();
    private int SendIndex=-1,SelectIndex=-1;

    private void Config6Bind() {
        BindCompont6();
        SendList.clear();
        for (int i=0;i< data.length;i++){
            SendList.add(data[i]);
        }
        OutputAdapter outputAdapter =new OutputAdapter(SettingPage5.this, R.layout.fruit_item,SendList);
        list1.setAdapter(outputAdapter);
        list1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> parent, View view,
                                              int position, long id) {
                outputAdapter.setClickPosition(position);
                outputAdapter.notifyDataSetChanged();
                SendIndex=position;
                String  SelectStr = data[position];
                Toast.makeText(SettingPage5.this, SelectStr, Toast.LENGTH_SHORT).show(); } });
    }

    Map<String,String> map=new HashMap<>();
    private ImageButton btn1,btn2,btn3,btn4;
    private Button btn5;
    private ListView list1,list2 ;
    private TextView textView;
    private String PrintStr="";
    private void BindCompont6() {
        btn1=findViewById(R.id.SingleRight);
        btn1.setOnClickListener(this);
        btn2=findViewById(R.id.SingleLeft);
        btn2.setOnClickListener(this);
        btn3=findViewById(R.id.TotalRight);
        btn3.setOnClickListener(this);
        btn4=findViewById(R.id.TotalLeft);
        btn4.setOnClickListener(this);
        btn5=findViewById(R.id.printf);
        btn5.setOnClickListener(this);

        list1=findViewById(R.id.SendList);
        list2=findViewById(R.id.SendList1);
        textView=findViewById(R.id.textView);
        map.put("name","BigHang");
        map.put("age","18");
        map.put("gender","man");
        map.put("serial number","20221108001");
        map.put("sample number","101");
        map.put("result","35mol/L");
    }



    private void ChangeListView(){

        OutputAdapter outputAdapter1 =new OutputAdapter(SettingPage5.this, R.layout.fruit_item,SendList);
        list1.setAdapter(outputAdapter1);
        list1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> parent, View view,
                                              int position, long id) {
                outputAdapter1.setClickPosition(position);
                outputAdapter1.notifyDataSetChanged();
                SendIndex=position;
                String  SelectStr = data[position];
                Toast.makeText(SettingPage5.this, SelectStr, Toast.LENGTH_SHORT).show(); } });

        OutputAdapter outputAdapter2 =new OutputAdapter(SettingPage5.this, R.layout.fruit_item,SelectList);
        list2.setAdapter(outputAdapter2);
        list2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> parent, View view,
                                              int position, long id) {
                outputAdapter2.setClickPosition(position);
                outputAdapter2.notifyDataSetChanged();
                SelectIndex=position;
                String  SelectStr = SelectList.get(position);
                Toast.makeText(SettingPage5.this, SelectStr, Toast.LENGTH_SHORT).show(); } });
    }







    //*******************************config6 设置结果输出排序界面-End ***********************************
}