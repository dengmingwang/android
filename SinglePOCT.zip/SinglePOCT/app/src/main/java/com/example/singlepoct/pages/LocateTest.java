package com.example.singlepoct.pages;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.example.singlepoct.R;

import java.util.ArrayList;
import java.util.List;

public class LocateTest extends AppCompatActivity {

    public LocationClient mLocationClient;
    private TextView positionText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //没有它，会报错：Please recheck the setAgreePrivacy interface
       mLocationClient.setAgreePrivacy(true);
        try {
            //首先创建了一个LocationClient的实例，LocationClient的构建函数接收一个Context参数，
            //这里调用getApplicationContext()方法来获取一个全局的Context参数并传入。
            mLocationClient = new LocationClient(getApplicationContext());
        } catch (Exception e) {
            e.printStackTrace();
        }
        //然后调用LocationClient的registerLocationListener()方法来注册一个定位监听器，当获取到位置信息的时候，就会回调这个定位监听器。
        mLocationClient.registerLocationListener(new MyLocationListener());
        setContentView(R.layout.activity_locate_test);
        positionText = (TextView) findViewById(R.id.position_text_view);
        //怎样才能在运行时一次性申请3个权限呢?
        //创建一个空的List集合，然后依次判断这3个权限有没有被授权，
        //如果没被授权就添加到List集合中，最后将List转换成数组，
        //再调用ActivityCompat.requestPermissions()方法一次性申请。
        List<String> permissionList = new ArrayList<>();
        if (ContextCompat.checkSelfPermission(LocateTest.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            permissionList.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (ContextCompat.checkSelfPermission(LocateTest.this,Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            permissionList.add(Manifest.permission.READ_PHONE_STATE);
        }
        if (ContextCompat.checkSelfPermission(LocateTest.this,Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            permissionList.add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (! permissionList.isEmpty()) {
            String [] permissions = permissionList.toArray(new String[permissionList.size()]);
            ActivityCompat.requestPermissions(LocateTest.this,permissions,1);
        } else {
            requestLocation();
        }
        initLocation();
    }
    private void requestLocation() {
        mLocationClient.start();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 1:
                if (grantResults.length > 0) {
                    for (int result : grantResults) {
                        if (result != PackageManager.PERMISSION_GRANTED) {
                            Toast.makeText(this,"必须同意所有权限才能使用本程序",Toast.LENGTH_SHORT).show();
                            finish();
                            return;
                        }
                    }
                    requestLocation();
                } else {
                    Toast.makeText(this,"发生未知错误",Toast.LENGTH_SHORT).show();
                    finish();
                }
                break;
            default:
        }
    }

    private void initLocation(){
        LocationClientOption option = new LocationClientOption();
        option.setScanSpan(5000); option.setIsNeedAddress(true);
        mLocationClient.setLocOption(option);
    }
    public class MyLocationListener implements BDLocationListener {
        /**
         * MyLocationListener的onReceiveLocation()方法中:
         * 通过BDLocation的getLatitude()方法获取当前位置的纬度,
         * 通过getLongitude()方法获取当前位置的经度，
         * 通过getLocType()方法获取当前的定位方式，最终将结果组装成一个字符串，显示到TextView上面。
         */
        @Override
        public void onReceiveLocation(BDLocation location) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    StringBuilder currentPosition = new StringBuilder();
                    currentPosition.append("纬度：").append(location.getLatitude()). append("\n");
                    currentPosition.append("经线：").append(location.getLongitude()). append("\n");
                    currentPosition.append("国家：").append(location.getCountry()). append("\n");
                    currentPosition.append("省：").append(location.getProvince()). append("\n");
                    currentPosition.append("市：").append(location.getCity()). append("\n");
                    currentPosition.append("区：").append(location.getDistrict()). append("\n");
                    currentPosition.append("街道：").append(location.getStreet()). append("\n");
                    currentPosition.append("定位方式：");
                    if (location.getLocType() == BDLocation.TypeGpsLocation) { currentPosition.append("GPS"); }
                    else if (location.getLocType() == BDLocation.TypeNetWorkLocation)
                    { currentPosition.append("网络"); }
                    positionText.setText(currentPosition); }
            });
        }
    }
}