package com.example.singlepoct.pages;

import static com.example.singlepoct.pages.SingleTest7.byte2HexStr;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.singlepoct.Bean.UploadBean;
import com.example.singlepoct.R;
import com.example.singlepoct.utils.ChartUtil;
import com.example.singlepoct.utils.Tools;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import android_serialport_api.ComBean;
import android_serialport_api.SerialHelper;

public class ProjectEditPage4 extends AppCompatActivity implements View.OnClickListener {

    private Handler mHandler=new Handler(){
        @Override
        public void handleMessage(Message msg){
            switch(msg.what) {
                case 1:
                    Log.d("TAG","DrawCurve");
                    System.out.println("======================================");
                    break;
                case 2:
                    break;
                case 3:
                    break;
                case 4:
                    break;
                default:
                    break;
            }
        }

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_project_edit_page4);
        Bindcomponent();
        initUart();
        serialHelper.close();
        try {
            serialHelper.open();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private EditText URLStr;
    private LineChart lineChart;
    private Button btn_testCurve;
    private Button MenuBack;
    private Button BtnClick;
    private void Bindcomponent() {
        lineChart =findViewById(R.id.lineChart);
        btn_testCurve=findViewById(R.id.TestCurve);
        btn_testCurve.setOnClickListener(this);
        URLStr=findViewById(R.id.URL);
        MenuBack=findViewById(R.id.Menu_Back);
        MenuBack.setOnClickListener(this);
        BtnClick=findViewById(R.id.Btn_CLick);
        BtnClick.setOnClickListener(this);
    }

    private Boolean DetecteFlag=false;
    String SendToNetSt="大帅哥";
    String Receive1="";
    String ReceiveStr="";
    /**串口连接类：*/
    private SerialHelper serialHelper;
    //串口初始化
    private void initUart() {
        serialHelper = new SerialHelper() {
            @Override
            protected void onDataReceived(final ComBean ComRecData) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        StringBuilder sMsg = new StringBuilder();
                        String receiveData = new String(ComRecData.bRec);
                        Log.d("ASCII码",receiveData);
                        String BytesToStr =byte2HexStr(ComRecData.bRec);   //将 接收的16进制数转换成：16进制字符串
                        SendToNetSt=BytesToStr;
                        Log.d("接收到单次的Hex数据的字节数据为", String.valueOf(BytesToStr.length()/2));
                        Log.d("16进制",BytesToStr);
                        byte[] bytes =ComRecData.bRec;
                        if(BytesToStr.length()<8){
                            return;
                        }
                        String StrStart=BytesToStr.substring(0,4);
                        String EndStart=BytesToStr.substring(BytesToStr.length()-4);
                        char[] data16=BytesToStr.toCharArray();
                        if(StrStart.equals("AA55") && EndStart.equals("FFFE")){  //解析数据：一个字节是一个数据；汉字是2个字节白表示一个值。
                            if(data16[5]=='7'){
                                Datalist.clear();
                                String  Datastr =BytesToStr.substring(6,BytesToStr.length()-4);
                                Log.d("str",Datastr);
                                ReceiveStr=Datastr;
                                Log.d("ReceiveStr1",ReceiveStr);
                                int n= ((BytesToStr.length()-4)-6)/2;
                                Log.d("数值为：", String.valueOf(n));
                                int Sum=0;
                                Log.d("Datalist初始值1", String.valueOf(Datalist.size()));
                                if(n%2==0){ //数据完成，都是2个字节的整数倍。
                                  str=Datastr;
                                    Log.d("Datalist初始值2", String.valueOf(Datalist.size()));
//                                    if(Datalist.size()>0){
//                                        Datalist=new ArrayList<>();
//                                    }
//                                    List<String> xDataList = new ArrayList<>();// x轴数据源
//                                    List<Entry> yDataList = new ArrayList<>();// y轴数据数据源
//                                    int a=0;
                                    for(int i=0;i<Datastr.length();i=i+4){
                                        String  strX1=Datastr.substring(i,i+4);
                                        Log.d("strX1",strX1);
                                        int anInt1 = Integer.parseInt(strX1, 16);
                                        Log.d("anInt1", String.valueOf(anInt1));

                                        Datalist.add((float) anInt1);
                                    }
                                    ShowCurve(2);
                                    MyThread myThread = new MyThread();
                                    new Thread(myThread).start();
//                                    ChartUtil.showChart(ProjectEditPage4.this, lineChart, xDataList, yDataList, "电压峰值图", "电压峰值","");
                                }
                                Receive1= String.valueOf(Sum);
                            }
                        }
                        for (Float n: Datalist) {
                            Log.d("n值为：", String.valueOf(n));
                        }
                        Log.d("msg：串口1接受数格式为：HEX", BytesToStr);
                        sMsg.append(receiveData);
                        Log.d("msg：串口1接受数格式为：ASCLL", new String(ComRecData.bRec));
                        char[] data = receiveData.toCharArray();   //2054.
//
                        if(receiveData.equals("0xE1")){// 判断：1.测试时判断下是否正确扫描到试剂卡的条形吗，确认当前卡时正常放置。；正确，执行测试，错误弹窗提示。

                        }else if(receiveData.equals("0xE2")){  //判断是否正确插入ID卡。

                        }else if(receiveData.equals("0xE3")){  //判断是否打测试完成，可以进行打印操作。

                        }
                    }
                });
            }
        };
        serialHelper.setBaudRate(9600);
        serialHelper.setPort("/dev/ttyS3");
        Log.d("Baud",String.valueOf(serialHelper.getBaudRate()));
        Log.d("setPort",serialHelper.getPort());
        try {
            serialHelper.open();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    List<Float> Datalist= new ArrayList<>();
    List<Float> TWODataList=new ArrayList<>();


    //完成曲线展示:
    private void  ShowCurve(int Flag){
        List<String> xDataList = new ArrayList<>();// x轴数据源
        List<Entry> yDataList = new ArrayList<>();// y轴数据数据源
        if(Flag==2){
            Log.d("Datalist", String.valueOf(Datalist.get(1)));
            for (int i = 0; i < Datalist.size(); i++) {
                // x轴显示的数据
                xDataList.add("");
                //y轴生成float类型的随机数
                yDataList.add(new Entry(Datalist.get(i), i));
            }
           ChartUtil.showChart(this, lineChart, xDataList, yDataList, "电压峰值图", "电压峰值","");
           if(Datalist.size()!=0){
               Log.d("Datalsit","!0");
           } else {
               Log.d("Datalsit","0");
           }

        }
      if(Flag==1){
//             给上面的X、Y轴数据源做假数据测试
        for (int i = 0; i < 380; i++) {
            // x轴显示的数据
            xDataList.add("");
            //y轴生成float类型的随机数
            float value = (float) (Math.random() * 20000) + 100;
            yDataList.add(new Entry(value, i));
        }
//显示图表,参数（ 上下文，图表对象， X轴数据，Y轴数据，图表标题，曲线图例名称，坐标点击弹出提示框中数字单位）
      ChartUtil.showChart(this, lineChart, xDataList, yDataList, "趋势图", "","");
        }
//       // 给上面的X、Y轴数据源做假数据测试
//        for (int i = 0; i < 380; i++) {
//           // x轴显示的数据
//          xDataList.add("");
//            //y轴生成float类型的随机数
//            float value = (float) (Math.random() * 3) + 3;
//           yDataList.add(new Entry(value, i));
//        }
////显示图表,参数（ 上下文，图表对象， X轴数据，Y轴数据，图表标题，曲线图例名称，坐标点击弹出提示框中数字单位）
//        ChartUtil.showChart(this, lineChart, xDataList, yDataList, "供热趋势图", "供热量/时间","kw/h");
    }

    @Override
    public void onClick(View view) {
        int id= view.getId();
        switch (id){
            case R.id.TestCurve:
                //8.16暂时屏蔽一下：用电脑虚拟机发送数据，测试Java端数据接受情况
                Datalist.clear();
//                Log.d("Datalist.length", String.valueOf(Datalist.size()));
//                Log.d("Datalist.length", String.valueOf(URLStr.getText().toString()));
                serialHelper.sendHex("EE14FF");
                ShowCurve(1);
            break;

            case R.id.Btn_CLick:
//                //8.16暂时屏蔽一下：用电脑虚拟机发送数据，测试Java端数据接受情况
////                Datalist.clear();
//                Log.d("Btn_Click","onclick");
//                    ShowCurve(2);
//                if(DetecteFlag){
//                    Log.d("Detecte","True");
//                    Log.d("Datalist.length", String.valueOf(Datalist.size()));
//                    ShowCurve(2);
//                }else {
//                    Log.d("Detecte","False");
//                }
                MyThread myThread = new MyThread();
                new Thread(myThread).start();
                //0819修改系统时间：
//                try {
//                    Tools.getDate(2022,9,1,17,23);
//                } catch (Settings.SettingNotFoundException settingNotFoundException) {
//                    settingNotFoundException.printStackTrace();
//                }
                break;
            case R.id.Menu_Back:
                //8.16暂时屏蔽一下：用电脑虚拟机发送数据，测试Java端数据接受情况
               Intent intent = new Intent(ProjectEditPage4.this, MainActivity.class);
               startActivity(intent);
               serialHelper.close();
               finish();

                break;
            default:
                break;
        }
    }

    //建立hashMap:便于使用长字符串时，能一目了然这个字符串是什么意思：

    /**通讯测试字符串*/
    String DataStr="010F010F010F010F010F010F010F010F010F010" +
            "F010F010F010F010F010F010F010F010F010F010F010F010F010F" +
            "010F010F010F010F010F010F010F010F010F010F010F010F010F010" +
            "F010F010F010F010F010F010F010F010F010F010F010F010F010F010" +
            "F010F010F010F010F010F010F010E010E010E010E010E010E010E010E010" +
            "E010E010E010E010E010E010E010E010E010E010E010E010E010E010E01" +
            "0E010E010E010E010E010E010E010E010E010E010E010E010E010E010E010" +
            "E010E010E010E010E010E010E010E010E010E010E010E010E010F010F01100" +
            "11001110111011201120113011301130113011301130113011401140114011" +
            "50116011701180119011C011F0124012A0131013B014601530162017301860" +
            "19901AD01C101D501E701F7020502100218021C021C02190213020901FD01E" +
            "F01DF01CE01BC01AA019901880178016A015C01500146013C0134012D01270" +
            "122011E011B0118011601140113011201110111011101110111011101110111" +
            "01110111011101110111011101110111011101110111011101110111011101" +
            "1101110111011301150118011D0123012C0138014701590170018A01A901CB0" +
            "1F002180241026A029202B802DA02F7030E031F0328032A03250319030602EE" +
            "02D202B20290026C02490225020401E401C601AB0193017D016B015A014C0140" +
            "0136012E01270121011D01190116011401120111011101110111011101110111" +
            "01110111011101110111011101110111011101110111011101110111011101110" +
            "11101110111011101110111011101110111011101110111011101110111011101" +
            "1101110111011101110111011101110111011101110111011101110111011101" +
            "11011101110111011101110111011101110111011101110111011101110111011" +
            "10111011101110111011101110111011101110111011101110111011101110111" +
            "01110111011101110111011101110111011201130114011501160117011801190" +
            "11A011B011C011D011E011F011F01200120012101210122012201220122";
    String str="";
    int i=1;
    class MyThread implements Runnable {
        @Override
        public void run() {
            UploadBean uploadBean =new UploadBean();
            uploadBean.setJigoumingcheng("中日联合医院");
            uploadBean.setYiqileixing("单通道POCT检测仪");
            uploadBean.setYiqibianhao("202202001");
            uploadBean.setYangbenhao("001");
            uploadBean.setPicimingcheng("202202001");
            uploadBean.setNianling("20");
            uploadBean.setXingbie("男");
            i++;
            uploadBean.setLiushuihao("202210"+(100+i));
            uploadBean.setShijian("2022-10-11 10:50:30");
            uploadBean.setTiaoma("123456789");
            uploadBean.setXiangmumingcheng("C反应蛋白");
            uploadBean.setZixiangmu("PRC");
            uploadBean.setJiancejieguo("20");
            uploadBean.setJielun("阴性");
            uploadBean.setDanwei("mmol/L");
            uploadBean.setCeshifanwei("5~6");
            uploadBean.setFanyingzhi("888");
            uploadBean.setFengzhi("20000");
            uploadBean.setZhenduanbumen("化验科2科室");
            uploadBean.setCaozuoyuan("张三");
            uploadBean.setXiangxidizhi("吉林省长春市经济开发区");
            uploadBean.setCankaofanwei("1~30mmol/L");
            uploadBean.setC("8888");
            uploadBean.setT1("99999");
            uploadBean.setYangbenleixing("血浆");
            uploadBean.setJiancedianyazhi(DataStr);

            //发送接受到的电压坐标值。
//            String urlPath = "http://bighang.nat300.top/appPost";  	//URL    这个网址，是我用自己的笔记本作为服务器时的网址。估计应该是不能用了。
            String urlPath="http://192.168.110.64:8080/miniuiex_war/test/receivefromandroid" ;//这块补充明天单老师给的服务器网址 ************************************
//            String urlPath = "http://"+URLStr.getText().toString();  	//URL
            URL url = null;
            HttpURLConnection coon=null;
            BufferedReader reader = null;
            try {
                url = new URL(urlPath);
                coon = (HttpURLConnection) url.openConnection();
                coon.setRequestMethod("POST");	//请求方式为POST
                coon.setConnectTimeout(5000);   //连接超时
                coon.setRequestProperty("Content-Type", "application/json");     //设置发送的数据为 json 类型，会被添加到http body当中
//                String json = "{\"name\":\""+str+"\"," + "\"bulk\":" + "\"" +SendToNetSt+ "\"}";    //将要发送的花卉数据字符串连接成json格式
//                String json = "{\"name\":\""+str+"\"," + "\"bulk\":" + "\"" +SendToNetSt+ "\"}";
                String json = "{"+
                        "\""+uploadBean.GetJigoumingcheng()+"\":"+ "\"" +uploadBean.getJigoumingcheng()+ "\","+  //机构名称
                        "\""+uploadBean.GetYiqileixing()+"\":" + "\"" +uploadBean.getYiqileixing()+ "\","+          //仪器类型
                        "\""+uploadBean.GetYiqibianhao()+"\":" + "\"" +uploadBean.getYiqibianhao()+ "\","+      //仪器编号
                        "\""+uploadBean.GetYangbenhao()+"\":" + "\"" +uploadBean.getYangbenhao()+ "\","+           //样本号
                        "\""+uploadBean.GetPicimingcheng()+"\":"+ "\""  +uploadBean.getPicimingcheng()+ "\","+    //批次名称
                        "\""+uploadBean.GetNianling()+"\":" + "\"" +uploadBean.getNianling()+ "\","+              //年龄
                        "\""+uploadBean.GetXingbie()+"\":" + "\"" +uploadBean.getXingbie()+ "\","+                 //性别
                        "\""+uploadBean.GetLiushuihao()+"\":"+ "\""  +uploadBean.getLiushuihao()+ "\","+    //流水号
                        "\""+uploadBean.GetShijian()+"\":"+ "\""  +uploadBean.getShijian()+ "\","+    //时间
                        "\""+uploadBean.GetTiaoma()+"\":" + "\"" +uploadBean.getTiaoma()+ "\","+    //条码
                        "\""+uploadBean.GetXiangmumingcheng()+"\":" + "\"" +uploadBean.getXiangmumingcheng()+ "\","+     //项目名称
                        "\""+uploadBean.GetZixiangmu()+"\":" + "\"" +uploadBean.getZixiangmu()+ "\","+    //子项目
                        "\""+uploadBean.GetJiancejieguo()+"\":"+ "\""  +uploadBean.getJiancejieguo()+ "\","+     //检测结果
                        "\""+uploadBean.GetJielun()+"\":" + "\"" +uploadBean.getJielun()+ "\","+                    //结论
                        "\""+uploadBean.GetDanwei()+"\":"+ "\""  +uploadBean.getDanwei()+ "\","+    //单位
                        "\""+uploadBean.GetCeshifanwei()+"\":"+ "\""  +uploadBean.getCeshifanwei()+ "\","+    //测试范围
                        "\""+uploadBean.GetFanyingzhi()+"\":"+ "\""  +uploadBean.getFanyingzhi()+ "\","+    //反应值
                        "\""+uploadBean.GetFengzhi()+"\":" + "\"" +uploadBean.getFengzhi()+ "\","+    //峰值
                        "\""+uploadBean.GetZhenduanbumen()+"\":" + "\"" +uploadBean.getZhenduanbumen()+ "\","+    //诊断部门
                        "\""+uploadBean.GetCaozuoyuan()+"\":" + "\"" +uploadBean.getCaozuoyuan()+ "\","+    //操作员
                        "\""+uploadBean.GetXiangxidizhi()+"\":" + "\"" +uploadBean.getXiangxidizhi()+ "\","+     //详细地址
                        "\""+uploadBean.GetCankaofanwei()+"\":" + "\"" +uploadBean.getCankaofanwei()+ "\","+      //参考范围
                        "\""+uploadBean.GetC()+"\":" + "\"" +uploadBean.getC()+ "\","+      //C 值
                        "\""+uploadBean.GetT1()+"\":" + "\"" +uploadBean.getT1()+ "\","+      //T1
                        "\""+uploadBean.GetYangbenleixing()+"\":" + "\"" +uploadBean.getYangbenleixing()+ "\","+      //样本类型
                        "\""+uploadBean.GetJiancedianyazhi()+"\":" + "\"" +uploadBean.getJiancedianyazhi()+ "\""+     //检测电压值
                        "}";
                coon.setRequestProperty("Content-Length", String.valueOf(json.getBytes().length));
                //post请求把数据以流的方式写给服务器，指定请求的输出模式
                coon.setDoOutput(true);
                coon.getOutputStream().write(json.getBytes());
//                coon.getInputStream().read()
                //对获取到的输入流进行读取
                reader =new BufferedReader(new InputStreamReader(coon.getInputStream()));
                StringBuilder response = new StringBuilder();
                String line;
                while((line=reader.readLine())!=null){
                    response.append(line);
                }
                showResponse(response.toString());
                int code = coon.getResponseCode();
                if (code == 200) {
                    System.out.println("请求成功");
                    DetecteFlag=true;
                    System.out.println("DetecteFlag");
                } else {
                    System.out.println("请求失败");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }finally {
                if (reader !=null){   //关闭readerbuffer.
                    try {reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }if (coon !=null){  //关闭HTTP连接
                    coon.disconnect();
                }
            }
        }
    }

    TextView responseText;
    private void showResponse(final String response) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                // 在这里进行UI操作，将结果显示到界面上
//                responseText.setText(response);
                Log.d("接收到的指令：",response);
            }
        }
        );
    }

    //子线程绘制电压曲线：
    class MyThread2 implements Runnable {
        @Override
        public void run() {
            try {

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}