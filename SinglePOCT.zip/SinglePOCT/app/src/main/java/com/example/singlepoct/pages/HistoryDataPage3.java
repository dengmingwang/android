package com.example.singlepoct.pages;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Vibrator;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.singlepoct.Bean.DemoBean;
import com.example.singlepoct.Bean.OrdinaryData;
import com.example.singlepoct.R;
import com.example.singlepoct.Bean.QueryBean;

import android_serialport_api.SerialHelper;

import com.example.singlepoct.utils.ExcelUtil;
import com.example.singlepoct.utils.ExternalStorageMonitor;
import com.example.singlepoct.utils.Tools;
import com.example.singlepoct.utils.usbUtil;
import com.lingber.mycontrol.datagridview.DataGridView;
import com.lingber.mycontrol.datagridview.RecyclerviewAdapter;

import org.litepal.LitePal;
import org.litepal.crud.DataSupport;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import android_serialport_api.ComBean;

public class HistoryDataPage3 extends AppCompatActivity implements View.OnClickListener{
    LinearLayout linearLayout1;
    Vibrator vibrator;
    private int UPDATE_TIME=0;
    CheckBox TotalcheckBox;
    private Boolean TotalCheckBox=false;
    //当前页的第一项的地址序号；
    private int TotalIndex=0;
    private Handler mHandler=new Handler(){
        @Override
        public void handleMessage(Message msg){
            switch(msg.what) {
                case 0:
                    text_Date.setText(Tools.getDate().get(0));
                    text_time.setText(Tools.getDate().get(1));
                    break;
                case 1:
                    showHistory();
                    break;
                case 2:
                    viewShow =LayoutInflater.from(HistoryDataPage3.this).inflate(R.layout.history_page1 , linearLayout1 , true) ;
                    showHistory();
                    break;
                case 3://刷新表格当前页的勾选状态。
                    int a=0;
//                    TotalcheckBox.setChecked(false);
                    List<QueryBean> curListDatas= mDataGridView.getPageDatas();
                    for(int i=0;i<curListDatas.size();i++){
                        QueryBean queryBean= (QueryBean) mDataGridView.getRowData(i);
                        Log.d("queryBean",queryBean.toString());
//                        if (queryBean.getCheckBoxflag()){
//                            CheckBox checkBox =(CheckBox) mDataGridView.getItemCellContentView(i, 0); // 获取指定单元格内部View
//                            checkBox.setChecked(true);
//                            a++;
//                        }else {
//                            CheckBox checkBox =(CheckBox) mDataGridView.getItemCellContentView(i, 0); // 获取指定单元格内部View
//                            checkBox.setChecked(false);
//                            a--;
//                        }
                        if (queryBean.getCheckBox().isChecked()){
                            CheckBox checkBox =(CheckBox) mDataGridView.getItemCellContentView(i, 0); // 获取指定单元格内部View
                            checkBox.setChecked(true);
                            a++;
                        }else {
                            CheckBox checkBox =(CheckBox) mDataGridView.getItemCellContentView(i, 0); // 获取指定单元格内部View
                            checkBox.setChecked(false);
                            a--;
                        }
                    }
                    Log.d("a值", String.valueOf(a));
                    //进入页面，判断下全选框状态。
                    if(a==curListDatas.size()){
                        TotalcheckBox.setChecked(true);
                    }else {
                        TotalcheckBox.setChecked(false);
                    }
                    Log.d("33333","3333");
                    break;
                case 4:
                    ConstraintLayout layout = findViewById(R.id.histroy_Constraintlayout);
                    Log.d("生成","自定义View");
                    TextView textView = new TextView(HistoryDataPage3.this);
                    textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
                    textView.setGravity(Gravity.CENTER);
                    TotalcheckBox =new CheckBox(HistoryDataPage3.this);
                    TotalcheckBox.setScaleX(2);
                    TotalcheckBox.setScaleY(2);
                    ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams(
                            ConstraintLayout.LayoutParams.WRAP_CONTENT,
                            ConstraintLayout.LayoutParams.WRAP_CONTENT);
                    params.startToStart=R.id.textView18;
                    params.topToBottom=R.id.textView18;
                    params.setMargins(0,25,0,0);
                    layout.addView(TotalcheckBox,params);
                    TotalcheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                        @Override
                        public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                            if(buttonView.isChecked()){
                                TotalCheckBox=true;
                            }else{
                                TotalCheckBox=false;
                            }
                            Task3 task3 =new Task3();
                            new Thread(task3).start();
                            TotalIndex =(mDataGridView.getCurrentPageNumber()-1)*mDataGridView.getPageItems();
                            List<QueryBean> curListDatas= mDataGridView.getPageDatas();
                            Log.d("curListDatas", String.valueOf(curListDatas.size()));
                            for(int i=0;i<curListDatas.size();i++){
                                if (TotalCheckBox){
                                    CheckBox checkBox =(CheckBox) mDataGridView.getItemCellContentView(i, 0); // 获取指定单元格内部View
                                    checkBox.setChecked(true);
//                                    dataSource.get(i+TotalIndex).getCheckBox().setChecked(true);
                                }else {
                                    CheckBox checkBox =(CheckBox) mDataGridView.getItemCellContentView(i, 0); // 获取指定单元格内部View
                                    checkBox.setChecked(false);
//                                    dataSource.get(i+TotalIndex).getCheckBox().setChecked(false);
                                }
                            }
                            //整个列表全选：
//                            for (int i=0;i<dataSource.size();i++){
//                                dataSource.get(i).getCheckBox().setChecked(true);
//                            }
                        }
                    });
//                    Message message =new Message();    想不起来这段代码是来干什么的啦？？
//                    message.what = 6;
//                    mHandler.sendMessage(message);
                    break;
                case 5:
                    if(TotalCheckBox){
                        for (int i=0;i<dataSource.size();i++){
                            dataSource.get(i).getCheckBox().setChecked(true);
                        }
                    }else {
                        for (int i=0;i<dataSource.size();i++){
                            dataSource.get(i).getCheckBox().setChecked(false);
                        }
                    }
                    Log.d("2222","22222");
                    break;
                case 6:
                    dataSource.clear();
                    //将OrdinaryData 转成QueryBean.
                    List<OrdinaryData> OrdinaryDatas= DataSupport.findAll(OrdinaryData.class);
//                    for (OrdinaryData ordinarydata:OrdinaryDatas) {      //正序，时间由小到大。
//                        CheckBox checkBox=new CheckBox(HistoryDataPage3.this);
//                        dataSource.add(new QueryBean(checkBox,ordinarydata.getIndex(),ordinarydata.getSampleId(),ordinarydata.getItemName(),ordinarydata.getConcentrationValue()+"",ordinarydata.getTestTime(),""));
//                    Log.d("queryBean",ordinarydata.toString());
//                    }

                    for(int i=0;i<OrdinaryDatas.size();i++){ //得倒着排序，最新的在最前面：
//                        Log.d("date", String.valueOf(OrdinaryDatas.get(i).getTestDay()));
                        CheckBox checkBox=new CheckBox(HistoryDataPage3.this);
                        int index=OrdinaryDatas.size()-1-i;   //倒着排序的index；
                        dataSource.add(new QueryBean(checkBox,OrdinaryDatas.get(index).getIndex(),OrdinaryDatas.get(index).getSampleId(),
                                OrdinaryDatas.get(index).getItemName(),OrdinaryDatas.get(index).getConcentrationValue()+"",
                                OrdinaryDatas.get(index).getTestTime(),""));
                    }
                    mDataGridView.setDataSource(dataSource); //重新装载数据。
                    mDataGridView.updateAll(); // 更新所有数据。
                    break;
                default:
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_data_page3);
        Log.d("当前时间3",Tools.getDate().get(1));
//        vibrator = (Vibrator)getSystemService(VIBRATOR_SERVICE);
        Task2 task2= new Task2();
        mHandler.postDelayed(task2,0);
        LitePal.getDatabase();
        Log.d("当前时间4",Tools.getDate().get(1));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        setContentView(R.layout.view_null);
        Log.d("onDestroy","----");
    }

    private TextView text_Date,text_time;
    /**主菜单、查询确认、历史查看、分类统计、原始数据*/
    private Button btn_TotalBack,btn_Confirm,btn_History,btn_Classfy,btn_Fuzzyquery;
    /**上传、打印、导出和删除*/
    private Button btn_UpData,btn_Printf,btn_Export,btn_Delete;

    private TextView Text_Date1,Text_Date2;
    private Spinner spinner_project;

    private void BindComponent() {
        //btn1;
        btn_TotalBack=findViewById(R.id.Menu_Back);
        btn_TotalBack.setOnClickListener(this);

        btn_History=findViewById(R.id.HistoryView);
        btn_History.setOnClickListener(this);
        btn_Classfy=findViewById(R.id.Classfication);
        btn_Classfy.setOnClickListener(this);
        //btn2:
        btn_Confirm=findViewById(R.id.Confirm);
        btn_Confirm.setOnClickListener(this);

        btn_UpData=findViewById(R.id.UpData);
        btn_UpData.setOnClickListener(this);
        btn_Printf=findViewById(R.id.Printf);
        btn_Printf.setOnClickListener(this);
        btn_Export=findViewById(R.id.Export);
        btn_Export.setOnClickListener(this);
        btn_Delete=findViewById(R.id.Delete);
        btn_Delete.setOnClickListener(this);
        btn_Fuzzyquery=findViewById(R.id.FuzzyQuery);
        btn_Fuzzyquery.setOnClickListener(this);
        //textview
        text_Date=findViewById(R.id.Text_Date);
        text_time=findViewById(R.id.Text_Time);

        //EditText;
        Text_Date1 =findViewById(R.id.date1);
        Text_Date1.setOnClickListener(this);
        Text_Date2 =findViewById(R.id.date2);
        Text_Date2.setOnClickListener(this);
        datelist.add("POCT1");
        datelist.add("POCT2");
        datelist.add("POCT3");
        spinner_project=findViewById(R.id.ProjectListSprinner);
        Tools.initSpinner(this,spinner_project,datelist);
    }
    //这个starArray的数据不固定，会根据数据库保存的条码值的种类名，生成一个list.
    ArrayList<String> datelist = new ArrayList<String>();

    public class Task2 implements Runnable {
        @Override
        public void run() {
            Message message =new Message();
            message.what = 2;
            mHandler.sendMessage(message);
            BindComponent();
            Text_Date1.setText(Tools.getDate().get(4));
            Text_Date2.setText(Tools.getDate().get(3));
//            initUart();
            linearLayout1 =findViewById(R.id.LinearLayout);
            Task1 task1= new Task1(); //计时线程
            mHandler.postDelayed(task1,0);
        }
    }

    public class Task1 implements Runnable {
        @Override
        public void run() {
            Message message = mHandler.obtainMessage();
            message.what = UPDATE_TIME;
            mHandler.sendMessage(message);
            mHandler.postDelayed(this, 1000);
        }
    }
    // 负责全选按钮后，改变dataSource；
    public class Task3 implements Runnable {
        @Override
        public void run() {
            if(TotalCheckBox){
                for (int i=0;i<dataSource.size();i++){
                    dataSource.get(i).setCheckBoxflag(true);
                }
            }else{
                for (int i=0;i<dataSource.size();i++){
                    dataSource.get(i).setCheckBoxflag(false);
                }
            }
        }
    }

    private int a=20220918;
    private int DateStart;
    private int DateEnd;
    /**
     * @Author
     * @Time 2022/10/27 15:30
     * @Description
     * @param  num:表示将当前获取时间复制给特定的显示文本框，1：是主界面2个日期的前一个，2.是主界面2个日期的后一个。
     *                                                 3：查询弹窗的时间设置窗。
     */
    protected void showDatePickDlg(int num) {
        Calendar calendar = Calendar.getInstance();
        DatePickerDialog datePickerDialog = new DatePickerDialog(HistoryDataPage3.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                monthOfYear++;
                if(num==1){
                    String monthStr,DayStr,dateStr ;
                    if(monthOfYear<10){
                        monthStr="0"+monthOfYear;
                    }else{
                        monthStr=""+monthOfYear;
                    }
                    if(dayOfMonth<10){
                        DayStr="0"+dayOfMonth;
                    }else{
                        DayStr=""+dayOfMonth;
                    }
                    dateStr=year+monthStr+DayStr;
                    DateStart =Integer.parseInt(dateStr);
                    HistoryDataPage3.this.Text_Date1.setText(year + "-" + monthOfYear + "-" + dayOfMonth);
                }
                else if (num==2){
                    String monthStr,DayStr,dateStr ;
                    if(monthOfYear<10){
                        monthStr="0"+monthOfYear;
                    }else{
                        monthStr=""+monthOfYear;
                    }
                    if(dayOfMonth<10){
                        DayStr="0"+dayOfMonth;
                    }else{
                        DayStr=""+dayOfMonth;
                    }
                    dateStr=year+monthStr+DayStr;
                    DateEnd =Integer.parseInt(dateStr);
                    HistoryDataPage3.this.Text_Date2.setText(year + "-" + monthOfYear + "-" + dayOfMonth);
                } else if (num==3){
                    TestTime.setText(year + "-" + monthOfYear + "-" + dayOfMonth);
                }
            }
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
        datePickerDialog.show();
    }

    View viewShow;

    @Override
    public void onClick(View view) {
//        vibrator.vibrate(100);
        try {
            Tools.newBuzzer(true);
            Thread.sleep(100);
            Tools.newBuzzer(false);
            Thread.sleep(100);
            Tools.newBuzzer(false);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        int id = view.getId();
        switch (id){
            case R.id.Menu_Back:
                Intent intent3 = new Intent(HistoryDataPage3.this, MainActivity.class);
                startActivity(intent3);
                finish();
                break;
            case R.id.HistoryView:
                linearLayout1.removeAllViews();
                viewShow =LayoutInflater.from(this).inflate(R.layout.history_page1 , linearLayout1 , true) ;
                showHistory();
                break;
            case R.id.Classfication:
                linearLayout1.removeAllViews();
                viewShow =LayoutInflater.from(this).inflate(R.layout.history_page2 , linearLayout1 , true) ;
                break;
            case R.id.date1:  // 这连个按钮留出来做一下测试。
                showDatePickDlg(1);
                break;
            case R.id.date2:
                showDatePickDlg(2);
                break;
            case R.id.Confirm:
//                DateStart=Integer.parseInt(Text_Date1.getText().toString());
//                DateEnd= Integer.parseInt(Text_Date2.getText().toString());
                String[] splitdate1=Text_Date1.getText().toString().split("-");
                DateStart= Integer.parseInt(splitdate1[0]+splitdate1[1]+splitdate1[2]);

                String[] splitdate2=Text_Date2.getText().toString().split("-");
                DateEnd= Integer.parseInt(splitdate2[0]+splitdate2[1]+splitdate2[2]);

                if(DateStart < DateEnd){ //按日期查询测试记录：
                    dataSource.clear();
//                    List<OrdinaryData> OrdinaryDatas=DataSupport.where("TestDay> ? " ,""+(DateStart-1)).find(OrdinaryData.class);
//                    for(int i=0;i<OrdinaryDatas.size();i++){ //得倒着排序，最新的在最前面：
//                        CheckBox checkBox=new CheckBox(HistoryDataPage3.this);
//                        int index=OrdinaryDatas.size()-1-i;   //倒着排序的index；
//                        if(OrdinaryDatas.get(index).getTestDay()<DateEnd){
//                            dataSource.add(new QueryBean(checkBox,OrdinaryDatas.get(index).getIndex(),OrdinaryDatas.get(index).getSampleId(),
//                                    OrdinaryDatas.get(index).getItemName(),OrdinaryDatas.get(index).getConcentrationValue()+"",
//                                    OrdinaryDatas.get(index).getTestTime(),""));
//                        }
//                    }
                    List<OrdinaryData> OrdinaryDatas=DataSupport.where("TestDay between ?  and  ? ",""+(DateStart-1),""+DateEnd).find(OrdinaryData.class);
                    for(int i=0;i<OrdinaryDatas.size();i++){ //得倒着排序，最新的在最前面：
                        CheckBox checkBox=new CheckBox(HistoryDataPage3.this);
                        int index=OrdinaryDatas.size()-1-i;   //倒着排序的index；
//                        if(OrdinaryDatas.get(index).getTestDay()<DateEnd){
                        dataSource.add(new QueryBean(checkBox,OrdinaryDatas.get(index).getIndex(),OrdinaryDatas.get(index).getSampleId(),
                                OrdinaryDatas.get(index).getItemName(),OrdinaryDatas.get(index).getConcentrationValue()+"",
                                OrdinaryDatas.get(index).getTestTime(),""));
//                        }
                    }
                    mDataGridView.setDataSource(dataSource); //重新装载数据。
                    mDataGridView.updateAll(); // 更新所有数据。
                }else{//弹窗提示：重新设置日期。
                    Toast.makeText(this,"当前日期范围设置有误，请重设",Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.Printf:
                SelectSource=  mDataGridView.getSelectedRowsData();
                for(int i=0;i<SelectSource.size();i++){
                    Log.d(String.valueOf(SelectSource.get(i).getIndex()),SelectSource.get(i).toString());
                }
                break;
            case R.id.UpData:    //这个上传数据，是将数据上传到服务器？？？
////                searchPath();
////            String  usb_path = getExternalPath(HistoryDataPage3.this,"VendorCo U 盘")+"/";
//                String  usb_path= getUPath(HistoryDataPage3.this);
//               List<String> a = getUsbDrivePath();
////               if(a.size()!=0){
////                   Log.d("aa","bb");
////               }
//                StorageManager mStorageManager;
//                mStorageManager = (StorageManager) getSystemService(Context.STORAGE_SERVICE);
////获取所有挂载的设备（内部sd卡、外部sd卡、挂载的U盘）
//                List<StorageVolume> volumes = mStorageManager.getStorageVolumes();
//                try {
//                    Class<?> storageVolumeClazz = Class
//                            .forName("android.os.storage.StorageVolume");
//                    //通过反射调用系统hide的方法
//                    Method getPath = storageVolumeClazz.getMethod("getPath");
//                    Method isRemovable = storageVolumeClazz.getMethod("isRemovable");
//                    for (int i = 0; i < volumes.size(); i++) {
//                        StorageVolume storageVolume = volumes.get(i);//获取每个挂载的StorageVolume
//
//                        //通过反射调用getPath、isRemovable
//                        String storagePath = (String) getPath.invoke(storageVolume); //获取路径
//                        boolean isRemovableResult = (boolean) isRemovable.invoke(storageVolume);//是否可移除
//                        String description = storageVolume.getDescription(this);
//                        Log.d("wj", " i=" + i + " ,storagePath=" + storagePath
//                                + " ,isRemovableResult=" + isRemovableResult +" ,description="+description);
//                        if(i==1){
//                            fileStr=storagePath;
//                        }
//                    }
//                } catch (Exception e) {
//                    Log.d("jason", " e:" + e);
//                }


                ExternalStorageMonitor.getExternalPath(HistoryDataPage3.this,"USB drive");
                String strA=getUPath(HistoryDataPage3.this);
                break;
            case R.id.FuzzyQuery:    //精准查询 -根据高级信息进行精准查询。
                //新建弹窗：
                Adv_dialogFlag=true;
                FuzzyQuery();
                break;
            case R.id.TestTime:
                showDatePickDlg(3);
                break;
            case R.id.Export:   //将列表数据以EXCEL 的数据格式导入到U盘中。

                isGrantExternalRW(HistoryDataPage3.this);
                String filePath1=  Tools.getStoragePath(HistoryDataPage3.this,true);
//                String filePath=Tools.getUPath(HistoryDataPage3.this);
//                  File file = new File(filePath);
//                  if (!file.exists()) {
//                      file.mkdirs();
//                  }
                 List<String> UsbList=  usbUtil.getUsbPaths(HistoryDataPage3.this);
//                List<String> UsbList=getUsbDrivePath33();
//                  String filePath = getUdiskPath() +"/AndroidExcelDemo1";
//                  File file = new File(filePath);
//                  if (!file.exists()) {
//                      file.mkdirs();
//                  }
              if(UsbList.size()!=0){
                  String filePath = UsbList.get(0)+"/AndroidExcelDemo";
                  File file = new File(filePath);
                  if (!file.exists()) {
                      file.mkdirs();
                  }
                  String excelFileName = "/demo1635.xls";
                  String[] title = {"姓名", "年龄", "男孩"};
                  String sheetName = "demoSheetName";
                  List<DemoBean> demoBeanList = new ArrayList<>();
                  DemoBean demoBean1 = new DemoBean("张三", 10, true);
                  DemoBean demoBean2 = new DemoBean("小红", 12, false);
                  DemoBean demoBean3 = new DemoBean("李四", 18, true);
                  DemoBean demoBean4 = new DemoBean("王香", 13, false);
                  demoBeanList.add(demoBean1);
                  demoBeanList.add(demoBean2);
                  demoBeanList.add(demoBean3);
                  demoBeanList.add(demoBean4);
                  filePath =filePath+ excelFileName ;
                  ExcelUtil.initExcel(filePath, sheetName, title);
                  ExcelUtil.writeObjListToExcel(demoBeanList, filePath, HistoryDataPage3.this);
              }
              else{
                  Log.d("当前没插入USB","....");
              }
                break;
            case R.id.Delete:
                //删除选中数据条目： 1.获取到选中项目的流水号
                for(int i =0;i<dataSource.size();i++){
                    if(dataSource.get(i).getCheckBox().isChecked()){
                        Log.d("i值", String.valueOf(i));
//                        dataSource.get(i).delete(); //数据库删除
                        DataSupport.deleteAll(OrdinaryData.class,"index=?",dataSource.get(i).getIndex()); //好使
                    }
                }
//                刷新列表
                Message message = new Message();
                message.what=6;
                mHandler.sendMessage(message);
                break;
            default:
                break;
        }
    }

    public static String getUPath(Context context){
        StorageManager mStorageManager = (StorageManager) context.getSystemService(Activity.STORAGE_SERVICE);
        Class<?> volumeInfoClazz = null;
        Method getVolumes = null;
        Method isMountedReadable = null;
        Method getType = null;
        Method getPath = null;
        List<?> volumes = null;
        try {
            volumeInfoClazz = Class.forName("android.os.storage.VolumeInfo");
            getVolumes = StorageManager.class.getMethod("getVolumes");
            isMountedReadable = volumeInfoClazz.getMethod("isMountedReadable");
            getType = volumeInfoClazz.getMethod("getType");
            getPath = volumeInfoClazz.getMethod("getPath");
            volumes = (List<?>) getVolumes.invoke(mStorageManager);
            if (volumes.size()==0){
                return null;
            }
            for (Object vol : volumes) {
                if (vol != null && (boolean) isMountedReadable.invoke(vol) && (int) getType.invoke(vol) == 0) {
                    File path2 = (File) getPath.invoke(vol);
                    String p2 = path2.getPath();
                    Log.i("zbh",p2);
                    return p2;
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    /**
     * 获取储存权限
     * @param activity
     * @return
     */

    public static boolean isGrantExternalRW(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && activity.checkSelfPermission(
                Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {

            activity.requestPermissions(new String[]{
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
            }, 1);

            return false;
        }

        return true;
    }


    /**
     * 获取U盘路径
     * @return
     */
    private List<String> getUsbDrivePath33(){
        List<String> allPath = new ArrayList<>();
        StorageManager mStorageManager = (StorageManager) getSystemService(Context.STORAGE_SERVICE);
        Class<?> volumeInfoClazz = null;
        Method getVolumes = null;
        Method isMountedReadable = null;
        Method getType = null;
        Method getPath = null;
        List<?> volumes = null;
        try {
            volumeInfoClazz = Class.forName("android.os.storage.VolumeInfo");
            getVolumes = StorageManager.class.getMethod("getVolumes");
            isMountedReadable = volumeInfoClazz.getMethod("isMountedReadable");
            getType = volumeInfoClazz.getMethod("getType");
            getPath = volumeInfoClazz.getMethod("getPath");
            volumes = (List<?>) getVolumes.invoke(mStorageManager);
            if (volumes.size() == 0) {
                return null;
            }
            for (Object vol : volumes) {
                if (vol != null && (boolean) isMountedReadable.invoke(vol) && (int) getType.invoke(vol) == 0) {
                    File path2 = (File) getPath.invoke(vol);
                    String p2 = path2.getPath();
                    allPath.add(p2);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }


    public static String getUdiskPath() {
        String upath = "";
        try {
            Runtime runtime = Runtime.getRuntime();
            // 运行mount命令，获取命令的输出，得到系统中挂载的所有目录
            Process proc = runtime.exec("mount");
            InputStream is = proc.getInputStream();
            InputStreamReader isr = new InputStreamReader(is);
            String line;
            BufferedReader br = new BufferedReader(isr);
            while ((line = br.readLine()) != null) {
                Log.d("", line);
                // 将常见的linux分区过滤掉
                // SdList.add(line);
                if (line.contains("secure"))
                    continue;
                if (line.contains("asec"))
                    continue;
                // 下面这些分区是我们需要的
                if (line.contains("vfat") || line.contains("fuse")
                        || line.contains("fat") || (line.contains("ntfs"))) {
                    // 将mount命令获取的列表分割，items[0]为设备名，items[1]为挂载路径
                    String items[] = line.split(" ");
                    if (items != null && items.length > 1) {
                        String path = items[2].toLowerCase(Locale.getDefault());
                        // 添加一些判断，确保是sd卡，如果是otg等挂载方式，可以具体分析并添加判断条件
                        if (path != null && path.contains("media_rw")) {
                            upath = path;
                        }
                    }
                }
            }
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return upath;
    }


//    private String fileStr;
//    public static String getUPath(Context context){
//        StorageManager mStorageManager = (StorageManager) context.getSystemService(Activity.STORAGE_SERVICE);
//        Class<?> volumeInfoClazz = null;
//        Method getVolumes = null;
//        Method isMountedReadable = null;
//        Method getType = null;
//        Method getPath = null;
//        List<?> volumes = null;
//        try {
//            volumeInfoClazz = Class.forName("android.os.storage.VolumeInfo");
//            getVolumes = StorageManager.class.getMethod("getVolumes");
//            isMountedReadable = volumeInfoClazz.getMethod("isMountedReadable");
//            getType = volumeInfoClazz.getMethod("getType");
//            getPath = volumeInfoClazz.getMethod("getPath");
//            volumes = (List<?>) getVolumes.invoke(mStorageManager);
//            if (volumes.size()==0){
//                return null;
//            }
//            for (Object vol : volumes) {
//                if (vol != null && (boolean) isMountedReadable.invoke(vol) && (int) getType.invoke(vol) == 0) {
//                    File path2 = (File) getPath.invoke(vol);
//                    String p2 = path2.getPath();
//                    Log.d("zbh",p2);
//                    return p2;
//                }
//            }
//        } catch (Exception ex) {
//            ex.printStackTrace();
//        }
//        return null;
//    }

    private List<String> getUsbDrivePath(){
        List<String> allPath = new ArrayList<>();
        StorageManager mStorageManager = (StorageManager) getSystemService(Context.STORAGE_SERVICE);
        Class<?> volumeInfoClazz = null;
        Method getVolumes = null;
        Method isMountedReadable = null;
        Method getType = null;
        Method getPath = null;
        List<?> volumes = null;
        try {
            volumeInfoClazz = Class.forName("android.os.storage.VolumeInfo");
            getVolumes = StorageManager.class.getMethod("getVolumes");
            isMountedReadable = volumeInfoClazz.getMethod("isMountedReadable");
            getType = volumeInfoClazz.getMethod("getType");
            getPath = volumeInfoClazz.getMethod("getPath");
            volumes = (List<?>) getVolumes.invoke(mStorageManager);
            if (volumes.size() == 0) {
                return null;
            }
            for (Object vol : volumes) {
                if (vol != null && (boolean) isMountedReadable.invoke(vol) && (int) getType.invoke(vol) == 0) {
                    File path2 = (File) getPath.invoke(vol);
                    String p2 = path2.getPath();
                    allPath.add(p2);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }

    private void searchPath() {
        String filePath = "/proc/mounts";
        File file = new File(filePath);
        List<String> lineList = new ArrayList<>();
        InputStream inputStream =null;
        try {
            inputStream = new FileInputStream(file);
            if (inputStream != null) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "GBK");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                String line = "";
                while ((line = bufferedReader.readLine()) != null) {
                    if (line.contains("vfat")) {
                        lineList.add(line);
                    }
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        String editPath = lineList.get(lineList.size() - 1);
        int start = editPath.indexOf("/mnt");
        int end = editPath.indexOf(" vfat");
        String path = editPath.substring(start, end);
        Log.d("SelectBusLineDialog", "path: " + path);
    }

    /**
     * 根据label获取外部存储路径(此方法适用于android7.0以上系统)
     * @param context
     * @param label 内部存储:Internal shared storage    SD卡:SD card    USB:USB drive(USB storage)
     */
    @RequiresApi(api = Build.VERSION_CODES.N)
    public String getExternalPath(Context context, String label) {
        String path = "";
        StorageManager mStorageManager = (StorageManager) context.getSystemService(Context.STORAGE_SERVICE);
        //获取所有挂载的设备（内部sd卡、外部sd卡、挂载的U盘）
        List<StorageVolume> volumes = mStorageManager.getStorageVolumes();//此方法是android 7.0以上的
        try {
            Class<?> storageVolumeClazz = Class.forName("android.os.storage.StorageVolume");
            //通过反射调用系统hide的方法
            Method getPath = storageVolumeClazz.getMethod("getPath");
            Method isRemovable = storageVolumeClazz.getMethod("isRemovable");
//       Method getUserLabel = storageVolumeClazz.getMethod("getUserLabel");//userLabel和description是一样的
            for (int i = 0; i < volumes.size(); i++) {
                StorageVolume storageVolume = volumes.get(i);//获取每个挂载的StorageVolume
                // 通过反射调用getPath、isRemovable、userLabel
                String storagePath = (String) getPath.invoke(storageVolume); //获取路径
                boolean isRemovableResult = (boolean) isRemovable.invoke(storageVolume);//是否可移除
                String description = storageVolume.getDescription(context);//此方法是android 7.0以上的
                if (label.equals(description)){
                    Log.e("getExternalPath--", " i=" + i + " ,storagePath=" + storagePath +  " ,description=" + description);
                    path = storagePath;
                    break;
                }
            }
        } catch (Exception e) {
            Log.e("getExternalPath--", " e:" + e);
        }
        return path;
    }


    private boolean Adv_dialogFlag=false;
    /**当前的姓名选项*/
    private String nameStr="";
    private int age;
    private String ageUnit;
    private String gender;
    View dialogView;
    private TextView TestTime;
    //新建模糊查询弹窗：
    private void FuzzyQuery(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final AlertDialog dialog = builder.setCancelable(false).create();
        dialogView= View.inflate(this, R.layout.dialog_fuzzy_query, null);
        //设置对话框布局
        dialog.setView(dialogView);
        //确认和取消
        Button btn_Confirm = (Button) dialogView.findViewById(R.id.btn_Confirm);
        Button btn_Cancel = (Button) dialogView.findViewById(R.id.btn_Cancel);
        TestTime=dialogView.findViewById(R.id.TestTime); //查询时间
        EditText Name=dialogView.findViewById(R.id.Name);
        EditText Age=dialogView.findViewById(R.id.Age);
        Spinner AgeUint=dialogView.findViewById(R.id.AgeUint);
        Spinner Gender =dialogView.findViewById(R.id.Gender);
        String[] starArray2 = { "岁","周"};//用来表示孔位字符串数组     孔位的数字中间是不留空格。
        String[] starArray3 = { "男","女"};//用来表示孔位字符串数组     孔位的数字中间是不留空格。
        Tools.initSpinner(HistoryDataPage3.this,AgeUint,starArray2);
        Tools.initSpinner(HistoryDataPage3.this,Gender,starArray3);
        Gender.setSelection(1);
        TestTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickDlg(3);
            }
        });
        btn_Confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dataSource.clear();
                String nameStr="",ageStr="",genderStr="",TestTimeStr="";
                if(!Name.getText().toString().equals("")){
                    nameStr=Name.getText().toString();
                }else{
                    Toast.makeText(HistoryDataPage3.this,"请输入姓名",Toast.LENGTH_SHORT).show();
                    return;
                }
                if(!Age.getText().toString().equals("")){
                    if(Tools.isInteger(Age.getText().toString())){
                        age= Integer.parseInt(Age.getText().toString());
                        ageStr=Age.getText().toString();
                    }
                }else{
                    Toast.makeText(HistoryDataPage3.this,"请输入年龄",Toast.LENGTH_SHORT).show();
                    return;
                }
                genderStr=Gender.getSelectedItem().toString();
                if(!TestTime.getText().toString().equals("")){
                    TestTimeStr=TestTime.getText().toString();
                    Log.d("测试时间",TestTime.getText().toString());
                    dataSource=DataSupport.where("name = ? and age = ? and gender = ? and TestDay = ?",nameStr,ageStr,genderStr,TestTimeStr).limit(3).find(QueryBean.class);
                }else {
                    dataSource=DataSupport.where("name = ? and age = ? and gender = ?",nameStr,ageStr,genderStr).limit(3).find(QueryBean.class);
                }
                Log.d("dataSource", String.valueOf(dataSource.size()));
//                dataSource=DataSupport.where("name = ? and age = ? and gender = ? and testTime = ?","小猪","25","","2022-08-30").limit(3).find(QueryBean.class);
//                //根据设置的查询条件刷新列表。
//                dataSource=DataSupport.where("index > ? and sampleId < ?","50","2").limit(3).find(QueryBean.class);
                mDataGridView.setDataSource(dataSource); //重新装载数据。
                mDataGridView.updateAll(); // 更新所有数据。
                dialog.dismiss();
            }
        });
        btn_Cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
        if(Adv_dialogFlag){
            dialog.show();
            Adv_dialogFlag=false;
        }
        //调整dialog 的View 宽度。
        dialog.getWindow().setLayout(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);//通过此方式来设置dialog 的宽高
        Window mWindow = dialog.getWindow();
        WindowManager.LayoutParams lp = mWindow.getAttributes();
        lp.x = -200; //新位置X坐标
        lp.y = -150; //新位置Y坐标
        dialog.onWindowAttributesChanged(lp);
    }

    List<QueryBean> SelectSource;
    DataGridView mDataGridView;
    List<QueryBean> dataSource;
    private void showHistory(){
        mDataGridView = findViewById(R.id.datagridview);
        // 设置数据源
        dataSource = new ArrayList();

////    dataSource=DataSupport.findAll(QueryBean.class);
//    for(int i=0 ;i<20;i++){       //手动生成数据模板。2022-1017
//        CheckBox checkBox=new CheckBox(HistoryDataPage3.this);
////        checkBox.setChecked(true);
//        dataSource.add(new QueryBean(checkBox,""+(2022093000+i),"3","test","60mmol","2022-8-30",""));
//    }

//    将OrdinaryData 转成QueryBean.  给表格填充数据。
//    List<OrdinaryData> OrdinaryDatas= DataSupport.findAll(OrdinaryData.class);
//    for (OrdinaryData ordinarydata:OrdinaryDatas) {
//        CheckBox checkBox=new CheckBox(HistoryDataPage3.this);
//        dataSource.add(new QueryBean(checkBox,ordinarydata.getIndex(),ordinarydata.getSampleId(),ordinarydata.getItemName(),ordinarydata.getConcentrationValue()+"",ordinarydata.getTestTime(),""));
//    }
        List<OrdinaryData> OrdinaryDatas= DataSupport.findAll(OrdinaryData.class);
        for(int i=0;i<OrdinaryDatas.size();i++){ //得倒着排序，最新的在最前面：
//        if(i%2==0){
//            OrdinaryDatas.get(i).setTestDay(20221020);
//        }else{
//            OrdinaryDatas.get(i).setTestDay(20221021);
//        }
//        OrdinaryDatas.get(i).save();

            CheckBox checkBox=new CheckBox(HistoryDataPage3.this);
            int index=OrdinaryDatas.size()-1-i;   //倒着排序的index；
            dataSource.add(new QueryBean(checkBox,OrdinaryDatas.get(index).getIndex(),OrdinaryDatas.get(index).getSampleId(),
                    OrdinaryDatas.get(index).getItemName(),OrdinaryDatas.get(index).getConcentrationValue()+"",
                    OrdinaryDatas.get(index).getTestTime(),""));
        }

        // 设置列数
        mDataGridView.setColunms(7);
        // 设置表头内容

        //基本字段：流水号、样本号、项目、检测结果、检测时间、" page";
        mDataGridView.setHeaderContentByStringId(new int[]{R.string.history1_page,R.string.history1_index,R.string.history1_sampleNumber,R.string.history1_projectName,R.string.history1_concentration,R.string.history1_time,R.string.history1_page});
//    mDataGridView.setHeaderContentByStringId(new int[]{R.string.history1_index,R.string.history1_sampleNumber,R.string.history1_barcodeValue,
//            R.string.history1_projectName,R.string.history1_concentration,R.string.history1_unit,R.string.history1_sample_type,R.string.history1_time,
//            R.string.history1_name,R.string.history1_gender,R.string.age,R.string.history1_page});

//                private Integer index;
//                private Integer sampleId;
//                private Integer barcodeValue;
//                private String  projectName;
//                private Integer concentrationValue;
//                private String unit;
//                private String sampleType;
//                private String testTime;
//                private String name;
//                private String gender;
//                private Integer age;
        // 绑定字段
        mDataGridView.setFieldNames(new String[]{"checkbox","index","sampleId","projectName","concentrationValue",
                "testTime","page"});
        // 每个column占比
        mDataGridView.setColunmWeight(new float[]{1,3,3,3,2,3,1});
        // 每个单元格包含控件
//    mDataGridView.setCellContentView(new Class[]{TextView.class,TextView.class,TextView.class,TextView.class,TextView.class, TextView.class,
//            TextView.class, TextView.class, TextView.class, TextView.class, TextView.class,TextView.class});
        mDataGridView.setCellContentView(new Class[]{CheckBox.class, TextView.class,TextView.class,TextView.class,TextView.class,TextView.class, TextView.class,});
        // 设置数据源
        mDataGridView.setDataSource(dataSource);
//    // 单行选中模式
//    mDataGridView.setSelectedMode(2);
        // 启用翻页
        mDataGridView.setFlipOverEnable(true, 6, getFragmentManager());
        // 初始化表格
        mDataGridView.initDataGridView();
        // 单元格点击事件
        mDataGridView.setOnItemCellClickListener(new RecyclerviewAdapter.OnItemCellClickListener() {
            @Override
            public void onClick(View v, int row, int column) {
                CheckBox checkBox =(CheckBox) mDataGridView.getItemCellContentView(row, 0); // 获取指定单元格内部View
                int CurSelectIndex=(mDataGridView.getCurrentPageNumber()-1)*mDataGridView.getPageItems()+row;
                Log.d("当前点击的是第几行", String.valueOf(row));
                if(column<5){
                    if(checkBox.isChecked()){
                        checkBox.setChecked(false);
                        dataSource.get(CurSelectIndex).getCheckBox().setChecked(false);
                        Log.d("改变checkbox 状态","改为false");
                    }
                    else{
                        checkBox.setChecked(true);
                        Log.d("改变checkbox 状态1","改为true");
                        dataSource.get(CurSelectIndex).getCheckBox().setChecked(true);
                        if(dataSource.get(CurSelectIndex).getCheckBox().isChecked()){
                            Log.d("选中的项id",dataSource.get(CurSelectIndex).getIndex()) ;
                        }
                    }
                }
                Log.d("每页数据条数", String.valueOf(mDataGridView.getPageItems()));
                List<QueryBean> list1 = mDataGridView.getPageDatas();
                for(int i= 0 ;i<list1.size();i++){
                    if(list1.get(i).getCheckBox().isChecked()){
                        Log.d("第"+i+"个","true");
                    }else {
                        Log.d("第"+i+"个","False");
                    }
                }
            }
        });

        mDataGridView.setOnItemCellContentClickListener(new RecyclerviewAdapter.OnItemCellContentClickListener() {
            @Override
            public void onClick(View v, int row, int column) {
                CheckBox checkBox =(CheckBox) mDataGridView.getItemCellContentView(row, 0); // 获取指定单元格内部View
                Log.d("当前点击的是第几行", String.valueOf(row));
                Log.d("当前点击的是第几列", String.valueOf(column));
                int CurSelectIndex=(mDataGridView.getCurrentPageNumber()-1)*mDataGridView.getPageItems()+row;
                if(column<5){
                    if(column==0){
                        if(checkBox.isChecked()){
                            checkBox.setChecked(true);
//                        dataSource.get(CurSelectIndex).setCheckBoxflag(true);//这一行选中关键
                            Log.d("改变checkbox 状态2","改为true");
                            dataSource.get(CurSelectIndex).getCheckBox().setChecked(true);  //这一行代码没用
                        }
                        else{
                            checkBox.setChecked(false);
                            Log.d("改变checkbox 状态","改为false");
//                        dataSource.get(CurSelectIndex).setCheckBoxflag(false);//这一行选中关键
                            dataSource.get(CurSelectIndex).getCheckBox().setChecked(false);
                        }
                    }else{
                        if(checkBox.isChecked()){
                            checkBox.setChecked(false);
                            Log.d("改变checkbox 状态","改为false");
                            dataSource.get(CurSelectIndex).getCheckBox().setChecked(false);
//                        dataSource.get(CurSelectIndex).setCheckBoxflag(false);//这一行选中关键
                            List<QueryBean> curListDatas= mDataGridView.getPageDatas();
                            for(int i=0;i<curListDatas.size();i++){
                                QueryBean queryBean= (QueryBean) mDataGridView.getRowData(i);
                                Log.d("queryBean",queryBean.toString());}
                        }
                        else{
                            checkBox.setChecked(true);
                            Log.d("改变checkbox 状态3","改为true");
                            dataSource.get(CurSelectIndex).getCheckBox().setChecked(true);
                            List<QueryBean> curListDatas= mDataGridView.getPageDatas();
                            for(int i=0;i<curListDatas.size();i++){
                                QueryBean queryBean= (QueryBean) mDataGridView.getRowData(i);
                                Log.d("queryBean",queryBean.toString());}
                        }
                    }
                }
            }
        });

        mDataGridView.setOnSwitchPageNumberListener(new DataGridView.OnSwitchPageNumberListener() { // 翻页切换事件监听
            @Override
            public void onClick(String type) {
                //翻页之后，判断在翻页页面中的方框勾选状态。
                Message message =new Message();
                message.what = 3;
                mHandler.sendMessage(message);
                Log.d("翻页","翻页");
            }
        });
        //动态生成Checkbok选框：
        Message message =new Message();
        message.what =4;
        mHandler.sendMessage(message);
    }

    /**串口连接类：*/
    private SerialHelper serialHelper;
    //串口初始化
    private void initUart() {
        serialHelper = new SerialHelper() {
            @Override
            protected void onDataReceived(final ComBean ComRecData) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        StringBuilder sMsg = new StringBuilder();
                        String receiveData = new String(ComRecData.bRec);
                        sMsg.append(receiveData);
                        Log.d("msg：串口1", new String(ComRecData.bRec));
                        char[] data = receiveData.toCharArray();   //2054.
                    }
                });
            }
        };
        serialHelper.setBaudRate(9600);
        serialHelper.setPort("/dev/ttyS1");
        Log.d("Baud",String.valueOf(serialHelper.getBaudRate()));
        Log.d("setPort",serialHelper.getPort());
        try {
            serialHelper.open();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}