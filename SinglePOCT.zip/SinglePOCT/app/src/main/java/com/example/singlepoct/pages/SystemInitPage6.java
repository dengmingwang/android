package com.example.singlepoct.pages;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.TextView;

import com.example.singlepoct.R;
import com.example.singlepoct.utils.HorizontalProgressView;
import com.example.singlepoct.utils.Tools;
/**
 * @Author
 * @Time 2022/7/6 16:24
 * @Description  用来设置开机等待界面：
 */
public class SystemInitPage6 extends AppCompatActivity {
    private TextView text_Date,text_Time;
    private Handler mHandler=new Handler(){
        @Override
        public void handleMessage(Message msg){
            switch(msg.what) {
                case 0:
                    text_Date.setText(Tools.getDate().get(0));
                    text_Time.setText(Tools.getDate().get(1));
                    break;
                case 1:
                    progressBar.start();
                    break;
                case 2:
                    break;
                default:
                    break;
            }
        }

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_system_init);
        Task1 task1= new Task1();
        mHandler.postDelayed(task1,0);
        new myThread().start();//开启线程,进行跳转
    }

    private HorizontalProgressView progressBar;//进度条

    private void BindComponent() {
        text_Date=findViewById(R.id.Text_Date);
        text_Time=findViewById(R.id.Text_Time);
        progressBar=findViewById(R.id.progressBar2);
    }


    public class myThread extends Thread{
        @Override
        public void run() {

            ShowUI(false);
            BindComponent();
            try {
                sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Message msg=new Message();
            msg.what=1;
            mHandler.sendMessage(msg);//发送处理码
            try {
                sleep(4000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Intent intent = new Intent(SystemInitPage6.this, MainActivity.class);
            startActivity(intent);
            finish();
        }
    }

    public class Task1 implements Runnable {
        @Override
        public void run() {
            Message message = mHandler.obtainMessage();
            message.what = 0;
            mHandler.sendMessage(message);
            mHandler.postDelayed(this, 1000);
        }
    }



//1.为true显示 上下导航栏，为false隐藏。
    public void ShowUI(Boolean Flag){
        Intent intent = new Intent();
        intent.setAction("marvsmart_bar");
        if(Flag){
            intent.putExtra("marvsmart_swich", true);
            intent.putExtra("marvsmart_toast", "");//Toast,如果传入数据不为空且长度大于0，就以Toast弹出
        }else{
            intent.putExtra("marvsmart_swich", false);
            intent.putExtra("marvsmart_toast", "");//Toast,如果传入数据不为空且长度大于0，就以Toast弹出
        }
        sendBroadcast(intent);
    }
}