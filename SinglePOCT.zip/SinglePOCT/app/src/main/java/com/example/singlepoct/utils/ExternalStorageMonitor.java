package com.example.singlepoct.utils;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.storage.StorageManager;
import android.os.storage.StorageVolume;
import android.util.Log;

import androidx.annotation.RequiresApi;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * **************************
 * 项目名称：SinglePOCT
 *
 * @Author BigHang
 * 创建时间：2022/10/28  9:51
 * 用途:
 * **************************
 */
public class ExternalStorageMonitor {
    public static final String TAG = "ExternalStorageMonitor";
    public static final String EXTERNAL_STORAGE_DEFAULT_PATH = "/mnt/media_rw";
    private static ExternalStorageMonitor mInstance;
    private List<ExternalStorageDeviceListener> deviceListeners;
    private Context mContext;

    public static ExternalStorageMonitor getInstance(Context context){
        if (mInstance == null){
            synchronized (ExternalStorageMonitor.class){
                if (mInstance == null){
                    mInstance = new ExternalStorageMonitor(context);
                }
            }
        }
        return mInstance;
    }

    private ExternalStorageMonitor(Context context) {
        mContext = context.getApplicationContext();
        deviceListeners = new ArrayList<>();
    }

    public boolean init(ExternalStorageDeviceListener listener) {
        addDeviceListener(listener);
        startMonitor();
        // 在系统启动前是否已经有设备插入
        detectDevice();
        return true;
    }

    public void addDeviceListener(ExternalStorageDeviceListener listener) {
        for (ExternalStorageDeviceListener deviceListener : deviceListeners) {
            if (listener == deviceListener) {
                return;
            }
        }
        deviceListeners.add(listener);
    }

    public void removeDeviceListener(ExternalStorageDeviceListener listener) {
        deviceListeners.remove(listener);
    }

    /**
     * 开始监听USB设备的插拔
     *
     */
    private void startMonitor() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(UsbManager.ACTION_USB_DEVICE_ATTACHED);
        filter.addAction(UsbManager.ACTION_USB_DEVICE_DETACHED);

        USBBroadCastReceiver usbBroadCastReceiver = new USBBroadCastReceiver();
        mContext.registerReceiver(usbBroadCastReceiver, filter);
    }

    /**
     * 检测是否有USB设备的插入
     */
    private void detectDevice() {
        UsbManager usbManager = (UsbManager) mContext.getSystemService(Context.USB_SERVICE);
        if (usbManager != null) {
            HashMap<String, UsbDevice> deviceHashMap = usbManager.getDeviceList();
            if (deviceHashMap.isEmpty()) {
                return;
            }
            for (UsbDevice device : deviceHashMap.values()) {
                Log.d(TAG, "device name: " + device.getDeviceName() + "\nvendor id:" + device.getVendorId());
                dispatchAttachedListener();
            }
        }
    }

    private void dispatchAttachedListener() {
        for (ExternalStorageDeviceListener deviceListener : deviceListeners) {
            deviceListener.onAttached();
        }
    }

    private void dispatchDetachedListener() {
        for (ExternalStorageDeviceListener deviceListener : deviceListeners) {
            deviceListener.onDetached();
        }
    }

    public interface ExternalStorageDeviceListener {
        void onAttached();

        void onDetached();
    }

    private class USBBroadCastReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.d(TAG, "onReceive: ");
            switch (intent.getAction()) {
                case UsbManager.ACTION_USB_DEVICE_ATTACHED:
                    Log.d(TAG, "U盘插入");
                    dispatchAttachedListener();
                    break;
                case UsbManager.ACTION_USB_DEVICE_DETACHED:
                    Log.d(TAG, "U盘拔出");
                    dispatchDetachedListener();
                    break;
                default:
                    break;
            }
        }
    }


    /**
     * 根据label获取外部存储路径(此方法适用于android7.0以上系统)
     * @param context
     * @param label 内部存储:Internal shared storage    SD卡:SD card    USB:USB drive(USB storage)
     */
    @RequiresApi(api = Build.VERSION_CODES.N)
    public static String getExternalPath(Context context, String label) {
        String path = "";
        StorageManager mStorageManager = (StorageManager) context.getSystemService(Context.STORAGE_SERVICE);
        //获取所有挂载的设备（内部sd卡、外部sd卡、挂载的U盘）
        List<StorageVolume> volumes = mStorageManager.getStorageVolumes();//此方法是android 7.0以上的
        try {
            Class<?> storageVolumeClazz = Class.forName("android.os.storage.StorageVolume");
            //通过反射调用系统hide的方法
            Method getPath = storageVolumeClazz.getMethod("getPath");
            Method isRemovable = storageVolumeClazz.getMethod("isRemovable");
//       Method getUserLabel = storageVolumeClazz.getMethod("getUserLabel");//userLabel和description是一样的
            for (int i = 0; i < volumes.size(); i++) {
                StorageVolume storageVolume = volumes.get(i);//获取每个挂载的StorageVolume
                // 通过反射调用getPath、isRemovable、userLabel
                String storagePath = (String) getPath.invoke(storageVolume); //获取路径
                boolean isRemovableResult = (boolean) isRemovable.invoke(storageVolume);//是否可移除
                String description = storageVolume.getDescription(context);//此方法是android 7.0以上的
                if (label.equals(description)){
                    path = storagePath;
                    break;
                }
                Log.d("storagePath",storagePath);
//                LogUtils.d(TAG+"getExternalPath--", " i=" + i + " ,storagePath=" + storagePath +  " ,description=" + description);
            }
        } catch (Exception e) {
//            LogUtils.d(TAG+"getExternalPath--", " e:" + e);
        }
        return path;
    }

    
}

