package com.example.singlepoct.pages;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Vibrator;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.singlepoct.R;
import com.example.singlepoct.utils.Tools;

import java.util.Calendar;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    //全局变量：
    Tools tool;
    private int UPDATE_TIME=0;
    private Handler mHandler=new Handler(){
        @SuppressLint("HandlerLeak")
        @Override
        public void handleMessage(Message msg){
            switch(msg.what) {
                case 0:
                    textDate.setText(Tools.getDate().get(0));
                    textTime.setText(Tools.getDate().get(1));
                    break;
                case 1:
                    break;
                default:
                    break;
            }
        }

    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Tools.LanguageUtil(MainActivity.this,false);
        setContentView(R.layout.activity_main);
        BindComponent();
        MyThread myThread = new MyThread();
        new Thread(myThread).start();

    }

    class MyThread implements Runnable { @Override public void run() {
//        BindComponent();
        vibrator = (Vibrator)getSystemService(VIBRATOR_SERVICE);
        tool =new Tools();
        Task1 task1= new Task1();
        mHandler.postDelayed(task1,0);
    }
    }

    private Button singTest,batchTesting,historicalData,projectManagement,SystemSettings;
    private Button btn_menuBack;
    private TextView textDate,textTime;
    private void BindComponent() {
        //菜单按钮
        singTest=findViewById(R.id.SingTest);
        singTest.setBackgroundResource(R.drawable.btn_menu_selet1);
        singTest.setOnClickListener(this);


        batchTesting=findViewById(R.id.BatchTesting);
        batchTesting.setBackgroundResource(R.drawable.btn_menu_selet2);
        batchTesting.setOnClickListener(this);


        historicalData=findViewById(R.id.HistoricalData);
        historicalData.setBackgroundResource(R.drawable.btn_menu_selet3);
        historicalData.setOnClickListener(this);

        projectManagement=findViewById(R.id.ProjectManagement);
        projectManagement.setBackgroundResource(R.drawable.btn_menu_selet4);
        projectManagement.setOnClickListener(this);

        SystemSettings=findViewById(R.id.SystemSettings);
        SystemSettings.setBackgroundResource(R.drawable.btn_menu_selet5);
        SystemSettings.setOnClickListener(this);
        //界面文字
        textDate=findViewById(R.id.Text_Date);
        textTime=findViewById(R.id.Text_Time);
        //返回按钮
        btn_menuBack=findViewById(R.id.Menu_Back);
        btn_menuBack.setOnClickListener(this);
    }


    Vibrator vibrator;
    boolean btnflag=false;
    Intent intent;
    @Override
    public void onClick(View v) {
        vibrator.vibrate(100);
        switch (v.getId()) {
            case R.id.button:
                btnflag=!btnflag;
                if(btnflag){
//                    serialHelper.sendHex("EE01FF");
//                    showUIBat(false,false);
                }else{
//                    serialHelper.sendHex("EE02FF");
//                    showUIBat(true,true);
                }
                break;
            case R.id.SingTest:
                intent = new Intent(MainActivity.this, TestPage1.class);
                startActivity(intent);
                Log.d("当前时间1",Tools.getDate().get(1));
//                finish();
                break;
            case R.id.BatchTesting:
                intent = new Intent(MainActivity.this, SingleTest7.class);
                startActivity(intent);
//                finish();
                break;
            case R.id.HistoricalData:
                intent = new Intent(MainActivity.this, HistoryDataPage3.class);
                startActivity(intent);
                Log.d("当前时间1",Tools.getDate().get(1));
                finish();
                break;
            case R.id.ProjectManagement:
                intent = new Intent(MainActivity.this, ProjectEditPage4.class);
                startActivity(intent);
//                finish();
                break;
            case R.id.SystemSettings:
                 intent = new Intent(MainActivity.this, SettingPage5.class);
                 startActivity(intent);
//                finish();
                break;
            default:
                break;
        }
    }



/*************************************************************************系统工具类**********************************************/
//    /**
//     * @Author 12622
//     * @Time 2022/7/5 10:29
//     * @Description  显示和隐藏系统的UIBar,Flag1:导航栏，Flag2:（状态栏,false 隐藏，true 显示）。 这个是之前南京软方Android屏幕。
//     */
//    private void showUIBat(boolean Flag1,Boolean Flag2){
//        if(Flag1){
//            Intent intent=new Intent();
//            intent.setAction("ACTION_SHOW_NAVBAR");
//            intent.putExtra("cmd","show");
//            sendBroadcast(intent,null);
//
//        }else{
//            Intent intent=new Intent();
//            intent.setAction("ACTION_SHOW_NAVBAR");
//            intent.putExtra("cmd","hide");
//            sendBroadcast(intent,null);
//        }
//        if(Flag2){
//            Intent intent=new Intent();
//            intent.setAction("ACTION_SHOW_STATUSBAR");
//            intent.putExtra("cmd","show");
//            sendBroadcast(intent,null);
//        }else {
//            Intent intent=new Intent();
//            intent.setAction("ACTION_SHOW_STATUSBAR");
//            intent.putExtra("cmd","hide");
//            sendBroadcast(intent,null);
//        }
//    }



    public class Task1 implements Runnable {
        @Override
        public void run() {
            Message message = mHandler.obtainMessage();
            message.what = UPDATE_TIME;
            mHandler.sendMessage(message);
            mHandler.postDelayed(this, 1000);
        }
    }

    private String  Str_Date,Str_Time;
}