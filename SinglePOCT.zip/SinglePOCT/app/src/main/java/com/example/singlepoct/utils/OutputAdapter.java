package com.example.singlepoct.utils;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.singlepoct.R;

import java.util.List;

/**
 * **************************
 * 项目名称：ListViewTest
 *
 * @Author BigHang
 * 创建时间：2022/8/29  17:02
 * 用途:
 * **************************
 */
public class OutputAdapter extends ArrayAdapter<String> {
    private int resourceId;
    private int aa=-1;
    public OutputAdapter(Context context, int textViewResourceId, List<String> objects)
    { super(context, textViewResourceId, objects);
        resourceId = textViewResourceId;
    }
    @Override public View getView(int position, View convertView, ViewGroup parent) {
        String str = getItem(position); // 获取当前项的Fruit实例
         View view = LayoutInflater.from(getContext()).inflate(resourceId, parent, false);
//         ImageView fruitImage = (ImageView) view.findViewById(R.id.fruit_image);
         TextView fruitName = (TextView) view.findViewById(R.id.fruit_name);
//         fruitImage.setImageResource(fruit.getImageId());
         fruitName.setText(str);
         if(aa==position){
             view.setBackgroundColor(Color.parseColor("#FF03DAC5"));
         }else{

         }
         return view;
         }

         public void setClickPosition(int aa){
             this.aa=aa;
         }


}
