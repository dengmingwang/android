package com.example.test.Bean;

/**
 * **************************
 * 项目名称：Test
 *
 * @Author BigHang
 * 创建时间：2022/10/30  15:06
 * 用途:
 * **************************
 */
public class Category {

    private int id;
    private String categoryName;
    private int categoryCode;
    public void setId(int id) {
        this.id = id;
    }
    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }
    public void setCategoryCode(int categoryCode) {
        this.categoryCode = categoryCode;
    }
}
