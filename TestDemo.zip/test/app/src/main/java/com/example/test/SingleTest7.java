package com.example.test;



import static com.example.test.utils.Tools.hexStr2Str;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;


import android_serialport_api.SerialHelper;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import android_serialport_api.ComBean;

public class SingleTest7 extends AppCompatActivity implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {

    private Handler mHandler=new Handler(){
        @Override
        public void handleMessage(Message msg){
            switch(msg.what) {
                case 1:
                    Text_receive.setText(Receive1);
                    Text_Voltage.setText(Receive1);
                    Log.d("设置电压值",Receive1);
                    break;
                case 2:
                    Text_CodeValue.setText(Receive1); //接收显示条形码。
                    Text_receive.setText(Receive1);
                    break;
                case 3:
                    Text_receive.setText(Receive1);
                    break;
                case 4:
                    Text_receive.setText(Receive1);
                    break;
                default:
                    break;
            }
        }

    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_test7);
        initUart();
        initUart2();
        BindComponent();
    }

    private Button btn_ForwardInit,btn_BackInit,btn_InstrumentInit;
    private Button btn_ScanPosition,btn_Detect;
    private Button btn_ReadVoltage,btn_ReadCode;
    private Button btn_MoveForward,btn_MoveBack;
    private TextView Text_Voltage,Text_CodeValue;
    private EditText Edit_MoveForward,Edit_MoveBack;
    private Switch lightswitch,DetectMode;
    private TextView Text_receive;
    private Button btn_printf;

    private Button btn_totalBack,btn_test;

    private void BindComponent() {
        btn_ForwardInit=findViewById(R.id.ForwardInit);
        btn_ForwardInit.setOnClickListener(this);
        btn_BackInit=findViewById(R.id.BackwardInit);
        btn_BackInit.setOnClickListener(this);
        btn_InstrumentInit=findViewById(R.id.InstrumentInit);
        btn_InstrumentInit.setOnClickListener(this);

        btn_ScanPosition=findViewById(R.id.ScanPosition);
        btn_ScanPosition.setOnClickListener(this);
        btn_Detect=findViewById(R.id.DetectionPosition);
        btn_Detect.setOnClickListener(this);
        btn_ReadVoltage=findViewById(R.id.ReadVoltage);
        btn_ReadVoltage.setOnClickListener(this);
        btn_ReadCode=findViewById(R.id.ReadCode);
        btn_ReadCode.setOnClickListener(this);

        btn_MoveForward=findViewById(R.id.MoveForward);
        btn_MoveForward.setOnClickListener(this);
        btn_MoveBack=findViewById(R.id.MoveBack);
        btn_MoveBack.setOnClickListener(this);

        Text_Voltage=findViewById(R.id.VoltageValue);
        Text_CodeValue=findViewById(R.id.CodeValue);
        Text_receive=findViewById(R.id.Test_update);

        lightswitch=findViewById(R.id.lightSwitch);
        lightswitch.setOnCheckedChangeListener(this);
        DetectMode=findViewById(R.id.TestMode_Test7);
        DetectMode.setOnCheckedChangeListener(this);

//        btn_totalBack=findViewById(R.id.Menu_Back);
//        btn_totalBack.setOnClickListener(this);

        btn_test=findViewById(R.id.Test_Test7);
        btn_test.setOnClickListener(this);

        Edit_MoveForward=findViewById(R.id.ForwardValue);
        Edit_MoveBack=findViewById(R.id.BackValue);
        btn_printf=findViewById(R.id.Printf_SingleTest7);
        btn_printf.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        int id =view.getId();
//        try {
//            Tools.newBuzzer(true);
//            Thread.sleep(100);
//            Tools.newBuzzer(false);
//        } catch (IOException e) {
//            e.printStackTrace();
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }

        switch (id){
//            case R.id.Menu_Back:
//                Intent intent = new Intent(SingleTest7.this, MainActivity.class);
//                startActivity(intent);
//                break;
            case R.id.ScanPosition:
                serialHelper.sendHex("EE01FF");
                break;
            case R.id.DetectionPosition:
                serialHelper.sendHex("EE02FF");
                break;
            case R.id.BackwardInit:
                serialHelper.sendHex("EE03FF");
                break;
            case R.id.ForwardInit:
                serialHelper.sendHex("EE04FF");
                break;
            case R.id.InstrumentInit:
                serialHelper.sendHex("EE053FF");
                break;
            case R.id.ReadVoltage:
                serialHelper.sendHex("EE06FF");
                break;
            case R.id.ReadCode:
                serialHelper.sendHex("EE07FF");
                break;
            case R.id.MoveForward:
                String str1=StringToHex2(Edit_MoveForward.getText().toString(),true);
                Log.d("str1",str1);
                serialHelper.sendHex(str1);
                break;
            case R.id.MoveBack:
                String str2=StringToHex2(Edit_MoveBack.getText().toString(),false);
                Log.d("str2",str2);
                serialHelper.sendHex(str2);
                break;
            case R.id.Test_Test7:
                if(!TestStr.equals(""))
                    serialHelper.sendHex(TestStr);
                else{//没选默认是 即时检测。
                    TestStr="EE12FF";
                    serialHelper.sendHex(TestStr);
                }
//                MyThread2 myThread2 =new MyThread2();
//                new Thread(myThread2).start();
                break;
            case R.id.Printf_SingleTest7:
                MyThread myThread =new MyThread();
                new Thread(myThread).start();
//                MyThread2 myThread2 =new MyThread2();
//                new Thread(myThread2).start();
//                Log.d("TAG","打印成功");
//                exportExcel(this);
//                serialHelper2.sendHex("012345");
                break;
            default:
                break;
        }
    }

    ArrayList<String> resultList = new ArrayList<>();
//    private void exportExcel(Context context) {
//        resultList= usbUtil.getUsbPaths(this);
//        TFCardUtil.getTfCardPaths(this);
//        String dirPath=resultList.get(0)+"/testApp";
//        File file = new File(dirPath);
//        if (!file.exists()) {
//            if(file.mkdirs()){
//                Log.d("Flag1","新建文件成功");
//            }else {
//            }
//        }else {
//            Log.d("Flag1","已存在当前要建立的文件夹");
//        }
//        String excelFileName = "/UsbTest.xls";
//        String[] title = {"姓名", "年龄", "男孩"};
//        String sheetName = "demoSheetName";
//
//
//        List<DemoBean> demoBeanList = new ArrayList<>();
//        for (int i=0;i<2000;i++){
//            DemoBean demoBean1 = new DemoBean("张三", 10, true);
//            demoBeanList.add(demoBean1);
//        }
//        DemoBean demoBean1 = new DemoBean("张三", 10, true);
//        DemoBean demoBean2 = new DemoBean("小红", 12, false);
//        DemoBean demoBean3 = new DemoBean("李四", 18, true);
//        DemoBean demoBean4 = new DemoBean("王香", 13, false);
//        demoBeanList.add(demoBean1);
//        demoBeanList.add(demoBean2);
//        demoBeanList.add(demoBean3);
//        demoBeanList.add(demoBean4);
//
//        dirPath = dirPath + excelFileName;
//        ExcelUtil.initExcel(dirPath, sheetName, title);
//        ExcelUtil.writeObjListToExcel(demoBeanList, dirPath, context);
//    }

    private String  StringToHex(String str,boolean flag){
        String sendStr="";
        String StrA="";
        if(str.length()==4){
            if(flag)
                StrA="EE22013030303000FF";
            else
                StrA="EE22023030303000FF";
            char[] charA= StrA.toCharArray();
            char[] chars= str.toCharArray();
            charA[7]=chars[0];
            charA[9]=chars[1];
            charA[11]=chars[2];
            charA[13]=chars[3];
            sendStr= new String(charA);
        }else if(str.length()==3){
            if(flag)
                StrA="EE220130303000FF";
            else
                StrA="EE220230303000FF";
            char[] charA= StrA.toCharArray();
            char[] chars= str.toCharArray();
            charA[7]=chars[0];
            charA[9]=chars[1];
            charA[11]=chars[2];
            sendStr= new String(charA);
        }else if(str.length()==2){
            if(flag)
                StrA="EE2201303000FF";
            else
                StrA="EE2202303000FF";
            char[] charA= StrA.toCharArray();
            char[] chars= str.toCharArray();
            charA[7]=chars[0];
            charA[9]=chars[1];
            sendStr= new String(charA);
        }else if(str.length()==1){
            if(flag)
                StrA="EE22013000FF";
            else
                StrA="EE22023000FF";
            char[] charA= StrA.toCharArray();
            char[] chars= str.toCharArray();
            charA[7]=chars[0];
            sendStr= new String(charA);
        }
        return sendStr;
    }

    String SendStr="";
    private String StringToHex2(String str,boolean flag){
        int a = Integer.parseInt(str);
        String HexStr=String.format("%04x",a);
        if(flag){
            SendStr="EE2201"+HexStr+"FF";
        }else {
            SendStr="EE2202"+HexStr+"FF";
        }
        return SendStr;
    }

    //建立子线程，在子线程中处理带延时的数据指令。
    class MyThread implements Runnable {
        @Override
        public void run() {
//            printfUtil.setSerialHelper(serialHelper2);
//            printfUtil.Printer();
        }
    }

    class MyThread2 implements Runnable {
        @Override
        public void run() {
//            printfUtil.setSerialHelper(serialHelper);
//            printfUtil.Printer();
        }
    }

    private String TestStr="";
    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
//        try {
//            Tools.newBuzzer(true);
//        } catch (IOException e) {
//            e.printStackTrace();
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
        switch (compoundButton.getId()){
            case R.id.lightSwitch:
                if(b){//开灯
                    serialHelper.sendHex("EE15FF");
                }else {
                    serialHelper.sendHex("EE16FF");
                }
                break;
            case R.id.TestMode_Test7:
                if(b){//定时
                    TestStr="EE13FF";
                    Log.d("TestStr",TestStr);
                }else {//即时
                    TestStr="EE12FF";
                    Log.d("TestStr",TestStr);
                }
                break;
            default:
                break;
        }
    }

    String Receive1="";
    /**串口连接类：*/
    private SerialHelper serialHelper;
    private int barcodeFlag=0;
    //串口初始化
    private void initUart() {
        serialHelper = new SerialHelper() {
            @Override
            protected void onDataReceived(final ComBean ComRecData) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        StringBuilder sMsg = new StringBuilder();
                        String receiveData = new String(ComRecData.bRec);
                        Log.d("ASCII码",receiveData);
                        String BytesToStr =byte2HexStr(ComRecData.bRec);   //将 接收的16进制数转换成：16进制字符串
                        Log.d("接收到单次的Hex数据的字节数据为", String.valueOf(BytesToStr.length()/2));
                        Log.d("16进制",BytesToStr);
                        byte[] bytes =ComRecData.bRec;
                        if(BytesToStr.length()<8){
                            return;
                        }
                        String StrStart=BytesToStr.substring(0,4);
                        String EndStart=BytesToStr.substring(BytesToStr.length()-4);
                        char[] data16=BytesToStr.toCharArray();
                        if(StrStart.equals("AA55") && EndStart.equals("FFFE")){  //解析数据：一个字节是一个数据；汉字是2个字节白表示一个值。
                            if(data16[5]=='1'){
                                String  str =BytesToStr.substring(6,BytesToStr.length()-4);
                                Log.d("str",str);
                                int n= ((BytesToStr.length()-4)-6)/2;
                                Log.d("数值为：", String.valueOf(n));
                                int Sum=0;
//                                for(int i=6;i<BytesToStr.length()-4;i=i+4){
//                                    n--;
                                String  strX=BytesToStr.substring(6,10);
                                Log.d("strX",strX);
                                int anInt = Integer.parseInt(strX, 16);
//                                    Log.d("anInit", String.valueOf(anInt));
//                                    Log.d("anInit22", String.valueOf(Math.pow(10,n)*anInt));
//                                    Sum=Sum+(int) Math.pow(10,n)*anInt;
                                Log.d("当前电压值", String.valueOf(anInt));
//                                }
//                                int anInt = Integer.parseInt(str, 16);
                                Receive1= String.valueOf(anInt);
                                Log.d("Receive1",Receive1);
                                Message message = mHandler.obtainMessage();
                                message.what = 1;
                                mHandler.sendMessage(message);
                            }else if(data16[5]=='2'){  //这发送的条码值应该是数值
//                                String  str =BytesToStr.substring(6,BytesToStr.length()-4);
//                                Log.d("str",str);
//                                int n= ((BytesToStr.length()-4)-6)/2;
//                                Log.d("数值为：", String.valueOf(n));
//
//                                Receive1= String.valueOf(Sum);
                                Receive1=BytesToStr;
                                Message message = mHandler.obtainMessage();
                                message.what =2;
                                mHandler.sendMessage(message);

                            }else if(data16[5]=='3'){ //测试项目，这应该是中文。
                                String  str =BytesToStr.substring(6,BytesToStr.length()-4);
                                String str1=hexStr2Str(str,"GB2312");

                                Log.d("文件项目名",str1);
                                Receive1=str1;
                                Message message = mHandler.obtainMessage();
                                message.what = 3;
                                mHandler.sendMessage(message);
                            }else if(data16[5]=='4'){//子项目名，这应该是字符文本。
                                String  str =BytesToStr.substring(6,BytesToStr.length()-4);
                                String str1=hexStr2Str(str,"GB2312");

                                Log.d("子项目名称",str1);
                                Receive1=str1;
                                Message message = mHandler.obtainMessage();
                                message.what = 4;
                                mHandler.sendMessage(message);
                            }else if(data16[5]=='5'){  //接收到下位机返回的结果数据值
                                Receive1=BytesToStr;
                                Message message = mHandler.obtainMessage();
                                message.what = 5;
                                mHandler.sendMessage(message);
                            }
                        }
                        Log.d("msg：串口1接受数格式为：HEX", BytesToStr);
                        sMsg.append(receiveData);
                        Log.d("msg：串口1接受数格式为：ASCLL", new String(ComRecData.bRec));
                        char[] data = receiveData.toCharArray();   //2054.
//
                        if(receiveData.equals("0xE1")){// 判断：1.测试时判断下是否正确扫描到试剂卡的条形吗，确认当前卡时正常放置。；正确，执行测试，错误弹窗提示。

                        }else if(receiveData.equals("0xE2")){  //判断是否正确插入ID卡。

                        }else if(receiveData.equals("0xE3")){  //判断是否打测试完成，可以进行打印操作。

                        }
                    }
                });
            }
        };
        serialHelper.setBaudRate(9600);
        serialHelper.setPort("/dev/ttyS1");
        Log.d("Baud",String.valueOf(serialHelper.getBaudRate()));
        Log.d("setPort",serialHelper.getPort());
        try {
            serialHelper.open();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


//    PrintfUtil printfUtil =new PrintfUtil();
    private SerialHelper serialHelper2;
    private int barcodeFlag2=0;
    //串口初始化
    private void initUart2() {
        serialHelper2 = new SerialHelper() {
            @Override
            protected void onDataReceived(final ComBean ComRecData) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        StringBuilder sMsg = new StringBuilder();
                        String receiveData = new String(ComRecData.bRec);
                        Log.d("ASCII码",receiveData);
                        String BytesToStr =byte2HexStr(ComRecData.bRec);   //将 接收的16进制数转换成：16进制字符串
                    }
                });
            }
        };
        serialHelper2.setBaudRate(9600);
//        serialHelper2.setPort("/dev/ttyCOM0");
//        serialHelper.setPort("/dev/ttyCOM0");
//        serialHelper.setPort("/dev/ttyS3");
        serialHelper2.setPort("/dev/ttyS3");

        Log.d("Baud",String.valueOf(serialHelper2.getBaudRate()));
        Log.d("setPort",serialHelper2.getPort());
        try {
            serialHelper2.open();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    /**
     * bytes转换成十六进制字符串
     * @param   b byte数组
     * @return String 每个Byte值之间空格分隔
     */
    public static String byte2HexStr(byte[] b)
    {
        String stmp="";
        StringBuilder sb = new StringBuilder("");
        for (int n=0;n<b.length;n++)
        {
            stmp = Integer.toHexString(b[n] & 0xFF);
            sb.append((stmp.length()==1)? "0"+stmp : stmp);
//            sb.append(" ");
        }
        return sb.toString().toUpperCase().trim();
    }
}